from __future__ import annotations

import os
import queue
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk

APP_NAME = "Clearway"
APP_VERSION = "Local App v0.5.16"
DEFAULT_PORT = 8545
RELEASE_HUB_URL = "https://clearway-demo-7udjmjj5jnsbrqn5bgjb3h.streamlit.app/"


def app_root() -> Path:
    # When bundled with PyInstaller, sys.executable is the launcher exe.
    # The packaged app should place the exe in the same folder as app/, config/, requirements.txt.
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


ROOT = app_root()
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"

CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("620x390")
        self.minsize(560, 360)
        self.configure(bg="#241D17")
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.started = False
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.palette = {
            "bg": "#241D17",
            "surface": "#30261E",
            "surface2": "#3A2F25",
            "text": "#F5EDE2",
            "muted": "#D8C7B3",
            "accent": "#B9855A",
            "accent2": "#D0A06F",
            "border": "#5A4939",
            "danger": "#C78369",
        }

        self._style()
        self._build_ui()
        self.after(150, self.drain_log)
        self.after(600, self.start)

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "DS.Horizontal.TProgressbar",
            troughcolor=self.palette["surface"],
            background=self.palette["accent"],
            bordercolor=self.palette["border"],
            lightcolor=self.palette["accent2"],
            darkcolor=self.palette["accent"],
        )

    def _build_ui(self) -> None:
        outer = tk.Frame(self, bg=self.palette["bg"])
        outer.pack(fill="both", expand=True, padx=26, pady=22)

        self.title_label = tk.Label(
            outer,
            text="Clearway",
            font=("Segoe UI", 20, "bold"),
            fg=self.palette["text"],
            bg=self.palette["bg"],
            anchor="w",
        )
        self.title_label.pack(fill="x")

        self.subtitle = tk.Label(
            outer,
            text="Starting the local app. This may take a minute the first time.",
            font=("Segoe UI", 10),
            fg=self.palette["muted"],
            bg=self.palette["bg"],
            anchor="w",
            justify="left",
        )
        self.subtitle.pack(fill="x", pady=(4, 18))

        card = tk.Frame(outer, bg=self.palette["surface"], highlightbackground=self.palette["border"], highlightthickness=1)
        card.pack(fill="x", pady=(0, 16))

        self.status = tk.Label(
            card,
            text="Preparing launcher...",
            font=("Segoe UI", 12, "bold"),
            fg=self.palette["text"],
            bg=self.palette["surface"],
            anchor="w",
        )
        self.status.pack(fill="x", padx=18, pady=(16, 6))

        self.detail = tk.Label(
            card,
            text="Checking the app files.",
            font=("Segoe UI", 10),
            fg=self.palette["muted"],
            bg=self.palette["surface"],
            anchor="w",
            wraplength=530,
            justify="left",
        )
        self.detail.pack(fill="x", padx=18, pady=(0, 12))

        self.progress = ttk.Progressbar(card, style="DS.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=18, pady=(0, 18))
        self.progress["value"] = 5

        button_row = tk.Frame(outer, bg=self.palette["bg"])
        button_row.pack(fill="x")

        self.open_btn = tk.Button(
            button_row,
            text="Open app",
            command=lambda: webbrowser.open(self.current_url()),
            state="disabled",
            bg=self.palette["accent"],
            fg="#1E1813",
            activebackground=self.palette["accent2"],
            activeforeground="#1E1813",
            disabledforeground="#7E6A56",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10, "bold"),
        )
        self.open_btn.pack(side="left")

        self.stop_btn = tk.Button(
            button_row,
            text="Stop app",
            command=self.stop_app,
            state="disabled",
            bg=self.palette["surface2"],
            fg=self.palette["text"],
            activebackground="#4A3C2F",
            activeforeground=self.palette["text"],
            disabledforeground="#7E6A56",
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10),
        )
        self.stop_btn.pack(side="left", padx=(10, 0))

        self.details_btn = tk.Button(
            button_row,
            text="Show details",
            command=self.show_details,
            bg=self.palette["surface2"],
            fg=self.palette["text"],
            activebackground="#4A3C2F",
            activeforeground=self.palette["text"],
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10),
        )
        self.details_btn.pack(side="left", padx=(10, 0))

        self.update_btn = tk.Button(
            button_row,
            text="Check for updates",
            command=self.check_for_updates,
            bg=self.palette["surface2"],
            fg=self.palette["text"],
            activebackground="#4A3C2F",
            activeforeground=self.palette["text"],
            relief="flat",
            padx=16,
            pady=8,
            font=("Segoe UI", 10),
        )
        self.update_btn.pack(side="left", padx=(10, 0))

        self.footer = tk.Label(
            outer,
            text=f"{APP_VERSION}  •  Local files stay on this computer",
            font=("Segoe UI", 9),
            fg="#BFAE9A",
            bg=self.palette["bg"],
            anchor="w",
        )
        self.footer.pack(fill="x", pady=(18, 0))

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def set_status(self, status: str, detail: str = "", value: int | None = None, busy: bool = False) -> None:
        def update() -> None:
            self.status.config(text=status)
            if detail:
                self.detail.config(text=detail)
            if value is not None:
                self.progress.config(mode="determinate")
                self.progress.stop()
                self.progress["value"] = value
            if busy:
                self.progress.config(mode="indeterminate")
                self.progress.start(10)
        self.after(0, update)

    def enqueue(self, text: str) -> None:
        self.log_queue.put(text)

    def drain_log(self) -> None:
        while not self.log_queue.empty():
            self.logs.append(self.log_queue.get_nowait())
        self.after(150, self.drain_log)

    def show_details(self) -> None:
        win = tk.Toplevel(self)
        win.title("Clearway details")
        win.geometry("820x520")
        win.configure(bg=self.palette["bg"])
        txt = ScrolledText(
            win,
            bg="#1E1813",
            fg=self.palette["text"],
            insertbackground=self.palette["text"],
            font=("Consolas", 9),
            relief="flat",
            padx=10,
            pady=10,
        )
        txt.pack(fill="both", expand=True, padx=14, pady=14)
        txt.insert("end", "".join(self.logs) or "No details yet.")
        txt.see("end")

    def backup_for_update(self) -> Path | None:
        """Make a small database backup before sending the user to the update hub."""
        try:
            db_path = ROOT / "data" / "development_system.db"
            if not db_path.exists():
                return None
            backup_dir = ROOT / "output" / "Backups" / "Updates"
            backup_dir.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            backup_path = backup_dir / f"development_system_before_update_{stamp}.db"
            backup_path.write_bytes(db_path.read_bytes())
            return backup_path
        except Exception as exc:
            self.enqueue(f"Update backup failed: {exc}\n")
            return None

    def check_for_updates(self) -> None:
        backup = self.backup_for_update()
        if backup:
            messagebox.showinfo(APP_NAME, f"A backup was created before opening the update hub:\n\n{backup}")
        else:
            messagebox.showinfo(APP_NAME, "Opening the update hub. No local database backup was needed or available.")
        webbrowser.open(RELEASE_HUB_URL)

    def find_python_cmd(self) -> list[str] | None:
        for cmd in (["py", "-3"], ["python"]):
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, creationflags=CREATE_NO_WINDOW)
                return cmd
            except Exception:
                continue
        return None

    def free_port(self, start: int = DEFAULT_PORT) -> int:
        for port in range(start, start + 80):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                try:
                    s.bind(("127.0.0.1", port))
                    return port
                except OSError:
                    continue
        return start

    def run_hidden(self, cmd: list[str], cwd: Path | None = None) -> int:
        self.enqueue("\n> " + " ".join(map(str, cmd)) + "\n")
        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd or ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            creationflags=CREATE_NO_WINDOW,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            self.enqueue(line)
        return proc.wait()

    def ensure_environment(self) -> bool:
        self.set_status("Checking app files", "Looking for the app and requirements file.", 10)
        if not APP_FILE.exists():
            messagebox.showerror(APP_NAME, f"Cannot find app/main.py in:\n{ROOT}")
            return False
        if not REQUIREMENTS.exists():
            messagebox.showerror(APP_NAME, f"Cannot find requirements.txt in:\n{ROOT}")
            return False

        self.set_status("Checking Python", "Looking for Python on this computer.", 20)
        pycmd = self.find_python_cmd()
        if pycmd is None:
            self.set_status("Python is needed", "Python 3.11 or later is required before the local app can start.", 0)
            if messagebox.askyesno(APP_NAME, "Python 3 is not installed or could not be found.\n\nOpen the Python download page now?"):
                webbrowser.open("https://www.python.org/downloads/")
            return False

        if not VENV_PYTHON.exists():
            self.set_status("Creating local environment", "This is only needed the first time the app is run.", 35, busy=True)
            code = self.run_hidden(pycmd + ["-m", "venv", str(VENV)], cwd=ROOT)
            if code != 0:
                self.set_status("Setup failed", "The local Python environment could not be created.", 0)
                messagebox.showerror(APP_NAME, "Could not create the local Python environment. Click Show details for more information.")
                return False

        self.set_status("Installing app requirements", "Checking and installing the packages needed by the app.", 55, busy=True)
        code = self.run_hidden([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], cwd=ROOT)
        if code != 0:
            self.set_status("Setup failed", "The required packages could not be installed.", 0)
            messagebox.showerror(APP_NAME, "Could not install required packages. Click Show details for more information.")
            return False
        return True

    def start(self) -> None:
        if self.started:
            return
        self.started = True
        threading.Thread(target=self.start_worker, daemon=True).start()

    def wait_for_server(self, timeout: int = 25) -> bool:
        start = time.time()
        while time.time() - start < timeout:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)
                try:
                    s.connect(("127.0.0.1", self.port))
                    return True
                except OSError:
                    time.sleep(0.5)
        return False

    def start_worker(self) -> None:
        try:
            if not self.ensure_environment():
                self.started = False
                return
            self.port = self.free_port(DEFAULT_PORT)
            self.set_status("Starting Clearway", "Opening the local app in your browser.", 80, busy=True)
            cmd = [
                str(VENV_PYTHON),
                "-m",
                "streamlit",
                "run",
                str(APP_FILE),
                "--server.port",
                str(self.port),
                "--server.headless",
                "true",
                "--browser.gatherUsageStats",
                "false",
            ]
            self.proc = subprocess.Popen(
                cmd,
                cwd=str(ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                creationflags=CREATE_NO_WINDOW,
            )
            self.stop_btn.config(state="normal")
            assert self.proc.stdout is not None
            threading.Thread(target=self.capture_streamlit_output, daemon=True).start()
            if self.wait_for_server():
                self.set_status("Clearway is running", f"The app is open at {self.current_url()}", 100)
                self.open_btn.config(state="normal")
                webbrowser.open(self.current_url())
            else:
                self.set_status("Still starting", f"If the browser does not open, click Open app. URL: {self.current_url()}", 90)
                self.open_btn.config(state="normal")
            code = self.proc.wait()
            self.enqueue(f"\nApp stopped with exit code {code}.\n")
            self.set_status("App stopped", "You can close this window.", 0)
        except Exception as exc:
            self.enqueue(f"\nError: {exc}\n")
            self.set_status("Something went wrong", "Click Show details for technical information.", 0)
            messagebox.showerror(APP_NAME, str(exc))
        finally:
            self.proc = None
            self.stop_btn.config(state="disabled")
            self.open_btn.config(state="disabled")
            self.started = False

    def capture_streamlit_output(self) -> None:
        try:
            if not self.proc or not self.proc.stdout:
                return
            for line in self.proc.stdout:
                self.enqueue(line)
        except Exception as exc:
            self.enqueue(f"Output capture error: {exc}\n")

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.set_status("Stopping app", "Closing the local Streamlit process.", 30, busy=True)
            self.proc.terminate()

    def on_close(self) -> None:
        self.stop_app()
        self.destroy()


if __name__ == "__main__":
    Launcher().mainloop()
