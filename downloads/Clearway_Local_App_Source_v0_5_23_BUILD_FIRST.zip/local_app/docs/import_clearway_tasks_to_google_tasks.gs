/**
 * Clearway Google Tasks importer
 *
 * Paste this script into Google Sheets Extensions > Apps Script.
 * Enable the Advanced Google service named "Tasks API" before running.
 *
 * Expected sheet columns:
 * Task ID, Task List, Title, Notes, Due Date, Reminder Time, Status
 */
function importClearwayTasksToGoogleTasks() {
  const sheet = SpreadsheetApp.getActiveSheet();
  const values = sheet.getDataRange().getValues();

  if (values.length < 2) {
    SpreadsheetApp.getUi().alert("No task rows found.");
    return;
  }

  const headers = values[0].map(String);
  const col = name => headers.indexOf(name);

  const requiredColumns = [
    "Task ID",
    "Task List",
    "Title",
    "Notes",
    "Due Date",
    "Reminder Time",
    "Status"
  ];

  for (const name of requiredColumns) {
    if (col(name) === -1) {
      throw new Error("Missing required column: " + name);
    }
  }

  let created = 0;
  let skipped = 0;

  for (let r = 1; r < values.length; r++) {
    const row = values[r];

    const title = String(row[col("Title")] || "").trim();
    const taskId = String(row[col("Task ID")] || "").trim();
    const notes = String(row[col("Notes")] || "").trim();
    const dueDate = row[col("Due Date")];
    const reminderTime = row[col("Reminder Time")];
    const status = String(row[col("Status")] || "needsAction").trim();
    const taskListName = String(row[col("Task List")] || "Clearway").trim() || "Clearway";

    if (!title) {
      skipped++;
      continue;
    }

    const fullNotes = [
      notes,
      "",
      taskId ? "Source Task ID: " + taskId : "",
      reminderTime ? "Reference time from Clearway: " + formatTime_(reminderTime) : ""
    ].filter(Boolean).join("\n");

    const task = {
      title: title,
      notes: fullNotes,
      status: status === "completed" ? "completed" : "needsAction"
    };

    if (dueDate) {
      task.due = formatDueDateForTasks_(dueDate);
    }

    const taskListId = getOrCreateTaskList_(taskListName);
    Tasks.Tasks.insert(task, taskListId);
    created++;
  }

  SpreadsheetApp.getUi().alert(
    "Google Tasks import complete.\n\nCreated: " + created + "\nSkipped: " + skipped
  );
}

// Backwards-compatible alias for older Clearway/Development System guides.
function importDevelopmentTasksToGoogleTasks() {
  importClearwayTasksToGoogleTasks();
}

function getOrCreateTaskList_(taskListName) {
  const existing = Tasks.Tasklists.list();

  if (existing.items) {
    for (const list of existing.items) {
      if (list.title === taskListName) {
        return list.id;
      }
    }
  }

  const created = Tasks.Tasklists.insert({
    title: taskListName
  });

  return created.id;
}

function formatDueDateForTasks_(value) {
  let date;

  if (Object.prototype.toString.call(value) === "[object Date]") {
    date = value;
  } else {
    date = new Date(value);
  }

  if (isNaN(date.getTime())) {
    throw new Error("Invalid due date: " + value);
  }

  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");

  // Google Tasks requires RFC3339 timestamp format.
  // The API stores only the date portion for due dates.
  return `${yyyy}-${mm}-${dd}T00:00:00.000Z`;
}

function formatTime_(value) {
  if (Object.prototype.toString.call(value) === "[object Date]") {
    return Utilities.formatDate(value, Session.getScriptTimeZone(), "HH:mm");
  }

  return String(value);
}
