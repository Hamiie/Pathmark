# Start Pathmark on Windows

Pathmark runs on your computer and opens in your browser.

## First setup

1. Extract the zip file.
2. Move the extracted `Pathmark_app` folder to a stable app location. Do not leave it in Downloads for day-to-day use.

   Simple option:

   ```text
   Documents\Pathmark App\Pathmark_app
   ```

   More app-like option:

   ```text
   %LOCALAPPDATA%\Pathmark\Pathmark_app
   ```

3. Open `Pathmark_app`.
4. Run `build_launcher_exe.bat` once.
5. This creates `Pathmark.exe`.
6. Open `Pathmark.exe` to start Pathmark.
7. In the launcher, use `Use Documents\Pathmark` or `Choose Pathmark folder` to set the workspace folder.

If the executable cannot be built, use `Start Pathmark.cmd` as the fallback launcher.

## What the Pathmark folder means

The Pathmark folder is the workspace for user projects. It is where Pathmark keeps area folders, exports, tasklists, backups, and the local database.

Pathmark defaults to creating and using:

```text
Documents\Pathmark
```

Exports and backups default to:

```text
Documents\Pathmark\00_System\Google Calendar Exports
Documents\Pathmark\00_System\Google Tasks Exports
Documents\Pathmark\00_System\Tasklists
Documents\Pathmark\00_System\Backups
```

You can change this in the launcher or in **Settings → Setup and folders**. There are quick buttons for `Documents\Pathmark` and `Downloads\Pathmark`, plus text boxes for custom folder paths.

## Areas

Pathmark detects the existing top-level folders inside your selected Pathmark folder and makes them available as Areas. Numbered folders such as `01_Body_And_Stability` are recommended because the number controls the order and makes the folder clearly identifiable as an Area. Existing ordinary folders can still be imported, but `00_System` is reserved and is not treated as an Area.

Continue keeping Pathmark project folders inside the selected Pathmark folder so the app can detect them as Areas.

## Updating Pathmark

Before updating, open the launcher and choose:

```text
Backup and open update hub
```

Then replace only:

```text
Pathmark_app
```

Do not replace:

```text
Documents\Pathmark
00_System
Backups
Tasklists
Google Calendar Exports
Google Tasks Exports
area folders
```

The app folder is replaceable. Your Pathmark workspace folder is not.

## Pinning Pathmark

After building `Pathmark.exe`, open it once, then right-click the taskbar icon and choose **Pin to taskbar**.
