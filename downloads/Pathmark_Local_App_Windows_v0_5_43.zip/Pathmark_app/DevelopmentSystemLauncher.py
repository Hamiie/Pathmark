from __future__ import annotations

import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time
import zipfile
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk

APP_NAME = "Pathmark"
APP_VERSION = "Local App v0.5.43"
WINDOWS_ONLY = True
DEFAULT_PORT = 8545
THEME_PRESETS = ["Pathmark", "Seasonal", "Persimmon", "Marigold", "Moss", "Lagoon", "Iris", "Rosewood", "Custom"]
THEME_MODES = ["Light", "Dark"]
RELEASE_HUB_URL = "https://pathmark.streamlit.app/"


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def documents_pathmark_root() -> Path:
    candidates: list[Path] = []
    for key in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        value = os.environ.get(key)
        if value:
            candidates.append(Path(value) / "Documents" / "Pathmark")
    candidates.append(Path.home() / "OneDrive" / "Documents" / "Pathmark")
    candidates.append(Path.home() / "Documents" / "Pathmark")
    for candidate in candidates:
        try:
            if candidate.parent.exists():
                return candidate
        except Exception:
            pass
    return Path.home() / "Documents" / "Pathmark"


def likely_pathmark_root() -> Path:
    root = app_root()
    try:
        if root.name.lower() in ("pathmark_app", "local_app") and root.parent.name.lower() == "pathmark":
            return root.parent
    except Exception:
        pass
    return documents_pathmark_root()


ROOT = app_root()
LAUNCHER_CONFIG = ROOT / "config" / "launcher_settings.json"
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"
ICON = ROOT / "assets" / "pathmark.ico"
ICON_PNG = ROOT / "assets" / "pathmark.png"
def load_launcher_config() -> dict:
    try:
        if LAUNCHER_CONFIG.exists():
            return json.loads(LAUNCHER_CONFIG.read_text(encoding="utf-8")) or {}
    except Exception:
        pass
    return {}


def load_configured_user_root() -> Path:
    data = load_launcher_config()
    value = data.get("pathmark_root")
    if value:
        return Path(value).expanduser()
    return likely_pathmark_root()


def load_configured_theme() -> tuple[str, str]:
    data = load_launcher_config()
    preset = data.get("theme_preset") or "Pathmark"
    mode = data.get("theme_mode") or "Light"
    if preset not in THEME_PRESETS:
        preset = "Pathmark"
    if mode not in THEME_MODES:
        mode = "Light"
    return preset, mode


def save_launcher_config(path: Path | None = None, theme_preset: str | None = None, theme_mode: str | None = None) -> None:
    data = load_launcher_config()
    if path is not None:
        data["pathmark_root"] = str(path)
    if theme_preset is not None:
        data["theme_preset"] = theme_preset
    if theme_mode is not None:
        data["theme_mode"] = theme_mode
    LAUNCHER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    LAUNCHER_CONFIG.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        # Keep a copy with the user's workspace so local launcher preferences can be backed up.
        if path is not None:
            system = Path(path).expanduser() / "00_System"
            system.mkdir(parents=True, exist_ok=True)
            (system / "pathmark_launcher_settings.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def save_configured_user_root(path: Path) -> None:
    save_launcher_config(path=path)


def set_user_root(path: Path) -> None:
    global USER_ROOT, USER_SYSTEM, USER_DB, USER_BACKUPS
    USER_ROOT = path.expanduser()
    USER_SYSTEM = USER_ROOT / "00_System"
    USER_DB = USER_SYSTEM / "pathmark.db"
    USER_BACKUPS = USER_SYSTEM / "Backups" / "Updates"


def ensure_user_workspace() -> None:
    USER_ROOT.mkdir(parents=True, exist_ok=True)
    for folder in (
        USER_SYSTEM,
        USER_SYSTEM / "Google Calendar Exports",
        USER_SYSTEM / "Google Tasks Exports",
        USER_SYSTEM / "Tasklists",
        USER_SYSTEM / "Backups",
    ):
        folder.mkdir(parents=True, exist_ok=True)
    readme = USER_ROOT / "README - Pathmark workspace.md"
    if not readme.exists():
        readme.write_text(
            """# Pathmark workspace

This is the folder Pathmark uses for projects, area folders, exports, tasklists, backups, and the local database.

Keep this workspace when updating Pathmark. Replace only the Pathmark_app folder in your app location.

## Area folder naming

Pathmark works best when area folders are numbered, for example:

```text
01_Body_And_Stability
02_Home_And_Garden
03_Making_And_Craft
```

00_System is reserved for Pathmark's database, exports, backups, and system files.

When you add a new area in the app, Pathmark suggests the next number automatically.
""",
            encoding="utf-8",
        )


USER_ROOT = load_configured_user_root()
USER_SYSTEM = USER_ROOT / "00_System"
USER_DB = USER_SYSTEM / "pathmark.db"
USER_BACKUPS = USER_SYSTEM / "Backups" / "Updates"
CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("940x780")
        self.minsize(900, 720)
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.started = False
        self.needs_workspace_choice = not LAUNCHER_CONFIG.exists()
        self.theme_preset, self.theme_mode = load_configured_theme()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        if ICON.exists():
            try:
                self.iconbitmap(default=str(ICON))
            except Exception:
                try:
                    self.iconbitmap(str(ICON))
                except Exception:
                    pass

        self.palette = {
            "bg": "#F7F6F2",
            "bg2": "#FBFAF7",
            "surface": "#FFFFFF",
            "surface2": "#EFEEE8",
            "text": "#1F2221",
            "muted": "#626966",
            "soft": "#8A918E",
            "accent": "#334E68",
            "accent2": "#7A4E7A",
            "accent_soft": "#E7EEF4",
            "warm": "#A66A43",
            "success": "#255833",
            "line": "#D8D4CB",
            "cream": "#F6F4EF",
        }
        self.configure(bg=self.palette["bg"])
        self._style()
        self._build_ui()
        self.after(150, self.drain_log)
        if self.needs_workspace_choice:
            self.after(550, self.prompt_workspace_choice)
        else:
            self.after(550, self.start)

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure(
            "Pathmark.Horizontal.TProgressbar",
            troughcolor=self.palette["surface2"],
            background=self.palette["warm"],
            bordercolor=self.palette["surface2"],
            lightcolor=self.palette["warm"],
            darkcolor=self.palette["warm"],
            thickness=12,
        )

    def _button(self, parent, text, command, *, primary=False, disabled=False):
        btn = tk.Button(
            parent,
            text=text,
            command=command,
            state="disabled" if disabled else "normal",
            bg=self.palette["accent"] if primary else self.palette["surface2"],
            fg="#FFFFFF" if primary else self.palette["text"],
            activebackground="#466782" if primary else "#E4E1D9",
            activeforeground="#FFFFFF" if primary else self.palette["text"],
            disabledforeground="#7A7E7B",
            relief="flat",
            padx=18,
            pady=11,
            font=("Segoe UI", 10, "bold" if primary else "normal"),
            cursor="hand2",
        )
        return btn

    def _draw_header_bg(self, canvas: tk.Canvas) -> None:
        # Soft product-page-inspired background: pale canvas with subtle accent circles.
        w, h = 840, 205
        canvas.create_rectangle(0, 0, w, h, fill=self.palette["bg2"], outline="")
        canvas.create_oval(-90, -120, 330, 260, fill="#E7EEF4", outline="")
        canvas.create_oval(610, -100, 1030, 230, fill="#F0E8F1", outline="")
        canvas.create_rectangle(0, h - 1, w, h, fill=self.palette["line"], outline="")

    def _make_logo_label(self, parent, size: int = 84) -> tk.Widget:
        frame = tk.Frame(parent, width=size, height=size, bg=self.palette["bg2"])
        frame.pack_propagate(False)
        self.logo_image = None
        if ICON_PNG.exists():
            try:
                raw = tk.PhotoImage(file=str(ICON_PNG))
                factor = max(1, raw.width() // size)
                self.logo_image = raw.subsample(factor, factor)
                return tk.Label(frame, image=self.logo_image, bg=self.palette["bg2"])
            except Exception:
                self.logo_image = None
        fallback = tk.Canvas(frame, width=size, height=size, bg=self.palette["bg2"], highlightthickness=0)
        fallback.create_oval(8, 8, size-8, size-8, fill="#182A27", outline="")
        fallback.create_line(size*.30, size*.68, size*.44, size*.51, size*.58, size*.58, size*.72, size*.34, fill="#F6F4EF", width=max(4, size//11), smooth=True)
        return fallback

    def _build_ui(self) -> None:
        # Product-page aligned launcher: same quiet background, badge, large title, and rounded action cards.
        header = tk.Frame(self, bg=self.palette["bg2"])
        header.pack(fill="x", padx=0, pady=0)

        hero = tk.Frame(header, bg=self.palette["bg2"])
        hero.pack(fill="x", padx=52, pady=(34, 26))

        logo_box = tk.Frame(hero, bg=self.palette["bg2"], width=46, height=46)
        logo_box.pack(anchor="w", pady=(0, 24))
        logo_box.pack_propagate(False)
        logo_widget = self._make_logo_label(logo_box, 46)
        logo_widget.pack(expand=True)

        badge = tk.Label(
            hero,
            text="Local app launcher",
            bg=self.palette["accent_soft"],
            fg=self.palette["accent"],
            padx=12,
            pady=6,
            font=("Segoe UI", 9, "bold"),
        )
        badge.pack(anchor="w", pady=(0, 12))

        tk.Label(
            hero,
            text="Pathmark",
            font=("Segoe UI Variable Display", 48, "bold"),
            fg="#111614",
            bg=self.palette["bg2"],
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            hero,
            text="Make time for routines. Reduce friction with prompts. Keep goals moving.",
            font=("Segoe UI", 11, "bold"),
            fg="#1F2221",
            bg=self.palette["bg2"],
            anchor="w",
        ).pack(fill="x", pady=(6, 0))

        body = tk.Frame(self, bg=self.palette["bg"])
        body.pack(fill="both", expand=True, padx=38, pady=(20, 24))

        action_card = tk.Frame(body, bg=self.palette["surface"], highlightbackground=self.palette["line"], highlightthickness=1)
        action_card.pack(fill="x")
        tk.Label(action_card, text="Pathmark folder and updates", bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 14, "bold"), anchor="w").pack(fill="x", padx=20, pady=(16, 4))
        self.workspace_text = tk.Label(
            action_card,
            text=self.workspace_message(),
            bg=self.palette["surface"],
            fg=self.palette["muted"],
            font=("Segoe UI", 9),
            anchor="w",
            wraplength=820,
            justify="left",
        )
        self.workspace_text.pack(fill="x", padx=20, pady=(0, 12))

        theme_row = tk.Frame(action_card, bg=self.palette["surface"])
        theme_row.pack(fill="x", padx=20, pady=(0, 12))
        tk.Label(theme_row, text="Default theme", bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 8))
        self.theme_var = tk.StringVar(value=self.theme_preset)
        self.mode_var = tk.StringVar(value=self.theme_mode)
        theme_select = ttk.Combobox(theme_row, textvariable=self.theme_var, values=THEME_PRESETS, state="readonly", width=16)
        theme_select.pack(side="left", padx=(0, 10))
        mode_select = ttk.Combobox(theme_row, textvariable=self.mode_var, values=THEME_MODES, state="readonly", width=8)
        mode_select.pack(side="left", padx=(0, 10))
        self.save_theme_btn = self._button(theme_row, "Save default theme", self.save_theme_choice)
        self.save_theme_btn.pack(side="left")
        tk.Label(theme_row, text="Pathmark matches the homepage and launcher. Seasonal changes with the season.", bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9)).pack(side="left", padx=(12, 0))

        actions = tk.Frame(action_card, bg=self.palette["surface"])
        actions.pack(fill="x", padx=15, pady=(0, 14))
        self.open_btn = self._button(actions, "Open Pathmark", lambda: webbrowser.open(self.current_url()), primary=True, disabled=True)
        self.stop_btn = self._button(actions, "Stop app", self.stop_app, disabled=True)
        self.default_root_btn = self._button(actions, "Use Documents\\Pathmark", self.use_documents_workspace)
        self.choose_root_btn = self._button(actions, "Choose workspace folder", self.choose_workspace_folder)
        self.backup_btn = self._button(actions, "Backup local data", self.backup_local_data)
        self.update_btn = self._button(actions, "Backup and open update hub", self.backup_and_check_for_updates)
        self.details_btn = self._button(actions, "Show details", self.show_details)
        for i, btn in enumerate([self.open_btn, self.stop_btn, self.default_root_btn, self.choose_root_btn, self.backup_btn, self.update_btn, self.details_btn]):
            btn.grid(row=i//4, column=i%4, sticky="ew", padx=5, pady=5)
        for i in range(4):
            actions.grid_columnconfigure(i, weight=1)
        tk.Label(
            action_card,
            text="On first launch, choose the workspace folder before Pathmark starts. This folder is where Pathmark keeps area folders, exports, tasklists, backups, and the local database. Keep the replaceable Pathmark_app folder somewhere separate, such as Documents\\Pathmark App.",
            bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9), justify="left", anchor="w", wraplength=820,
        ).pack(fill="x", padx=20, pady=(0, 14))

        card = tk.Frame(body, bg=self.palette["surface"], highlightbackground=self.palette["line"], highlightthickness=1)
        card.pack(fill="x", pady=(16, 0))

        self.status = tk.Label(
            card,
            text="Preparing Pathmark",
            font=("Segoe UI Variable Display", 18, "bold"),
            fg=self.palette["text"],
            bg=self.palette["surface"],
            anchor="w",
        )
        self.status.pack(fill="x", padx=24, pady=(22, 5))

        self.detail = tk.Label(
            card,
            text="Checking the Pathmark app files.",
            font=("Segoe UI", 10),
            fg=self.palette["muted"],
            bg=self.palette["surface"],
            anchor="w",
            wraplength=820,
            justify="left",
        )
        self.detail.pack(fill="x", padx=24, pady=(0, 16))

        self.progress = ttk.Progressbar(card, style="Pathmark.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=24, pady=(0, 18))
        self.progress["value"] = 5

        self.step_labels = []
        steps = tk.Frame(card, bg=self.palette["surface"])
        steps.pack(fill="x", padx=24, pady=(0, 20))
        for label in ["Choose workspace", "Check files", "Check Python", "Prepare environment", "Start app"]:
            row = tk.Label(steps, text=f"○ {label}", fg=self.palette["soft"], bg=self.palette["surface"], font=("Segoe UI", 9), anchor="w")
            row.pack(fill="x", pady=2)
            self.step_labels.append(row)

        help_card = tk.Frame(body, bg=self.palette["surface2"], highlightbackground=self.palette["line"], highlightthickness=1)
        help_card.pack(fill="x", pady=(16, 0))
        tk.Label(help_card, text="This opens Pathmark locally in your browser.", bg=self.palette["surface2"], fg=self.palette["text"], font=("Segoe UI", 10, "bold"), anchor="w").pack(fill="x", padx=18, pady=(12, 2))
        tk.Label(help_card, text=f"{APP_VERSION} · runs locally on this computer", bg=self.palette["surface2"], fg=self.palette["muted"], font=("Segoe UI", 9), anchor="w", wraplength=820, justify="left").pack(fill="x", padx=18, pady=(0, 12))

    def prompt_workspace_choice(self) -> None:
        self.set_status(
            "Choose your Pathmark folder",
            "Before Pathmark starts, choose where your projects, area folders, exports, tasklists, backups, and local database should be kept. Use Documents\\Pathmark, or choose an existing folder such as your current development folder.",
            8,
            0,
        )
        messagebox.showinfo(
            "Choose your Pathmark folder",
            "Before Pathmark starts, choose the workspace folder it should use.\n\n"
            "This is not the replaceable app folder. It is the folder Pathmark will use for your projects, area folders, exports, tasklists, backups, and local database.\n\n"
            "Choose Use Documents\\Pathmark to create the standard workspace, or Choose workspace folder to point Pathmark at an existing folder."
        )

    def workspace_message(self) -> str:
        return f"Pathmark folder: {USER_ROOT}\nDefault theme: {self.theme_preset} / {self.theme_mode}\nExports, backups, tasklists, and area folders are kept there."

    def refresh_workspace_message(self) -> None:
        try:
            self.workspace_text.config(text=self.workspace_message())
        except Exception:
            pass

    def save_theme_choice(self) -> None:
        self.theme_preset = self.theme_var.get() if hasattr(self, "theme_var") else self.theme_preset
        self.theme_mode = self.mode_var.get() if hasattr(self, "mode_var") else self.theme_mode
        if self.theme_preset not in THEME_PRESETS:
            self.theme_preset = "Pathmark"
        if self.theme_mode not in THEME_MODES:
            self.theme_mode = "Light"
        save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
        self.refresh_workspace_message()
        messagebox.showinfo("Theme saved", f"Pathmark will use {self.theme_preset} / {self.theme_mode} as the launcher setup theme. You can still change and save the theme inside the app later.")

    def use_documents_workspace(self) -> None:
        self.set_workspace(documents_pathmark_root())

    def choose_workspace_folder(self) -> None:
        selected = filedialog.askdirectory(
            title="Choose the folder Pathmark should use for projects and exports",
            initialdir=str(USER_ROOT.parent if USER_ROOT.parent.exists() else Path.home()),
        )
        if selected:
            self.set_workspace(Path(selected))

    def set_workspace(self, path: Path) -> None:
        set_user_root(path)
        self.theme_preset = self.theme_var.get() if hasattr(self, "theme_var") else self.theme_preset
        self.theme_mode = self.mode_var.get() if hasattr(self, "mode_var") else self.theme_mode
        save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
        ensure_user_workspace()
        self.refresh_workspace_message()
        messagebox.showinfo(
            "Pathmark folder set",
            "Pathmark will use this folder for your projects, area folders, exports, tasklists, and backups:\n\n"
            f"{USER_ROOT}\n\n"
            "Continue keeping your Pathmark project folders inside this architecture so the app can detect them as Areas.",
        )
        self.needs_workspace_choice = False
        if not self.started:
            self.after(150, self.start)

    def streamlit_env(self) -> dict[str, str]:
        env = os.environ.copy()
        env["PATHMARK_ROOT"] = str(USER_ROOT)
        env["PATHMARK_INITIAL_THEME_PRESET"] = self.theme_preset
        env["PATHMARK_INITIAL_THEME_MODE"] = self.theme_mode
        return env

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def mark_step(self, index: int) -> None:
        for i, lab in enumerate(self.step_labels):
            label_text = lab.cget("text").replace("○", "").replace("●", "").strip()
            if i < index:
                lab.config(text=f"● {label_text}", fg=self.palette["accent"])
            elif i == index:
                lab.config(text=f"● {label_text}", fg=self.palette["text"])
            else:
                lab.config(text=f"○ {label_text}", fg=self.palette["soft"])

    def set_status(self, status: str, detail: str = "", value: int | None = None, step: int | None = None) -> None:
        self.status.config(text=status)
        self.detail.config(text=detail or status)
        if value is not None:
            self.progress["value"] = value
        if step is not None:
            self.mark_step(step)
        self.update_idletasks()

    def log(self, text: str) -> None:
        self.logs.append(text)
        self.log_queue.put(text)

    def drain_log(self) -> None:
        try:
            while True:
                self.log_queue.get_nowait()
        except queue.Empty:
            pass
        self.after(250, self.drain_log)

    def choose_python(self) -> list[str]:
        candidates = [["py", "-3"], ["python"]]
        for cmd in candidates:
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True, creationflags=CREATE_NO_WINDOW)
                return cmd
            except Exception:
                continue
        raise FileNotFoundError("Python 3 was not found.")

    def port_free(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            return sock.connect_ex(("127.0.0.1", port)) != 0

    def choose_port(self) -> int:
        for port in range(DEFAULT_PORT, DEFAULT_PORT + 25):
            if self.port_free(port):
                return port
        return DEFAULT_PORT

    def run_and_log(self, args: list[str], label: str) -> None:
        self.log(f"$ {' '.join(args)}")
        proc = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=CREATE_NO_WINDOW)
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        code = proc.wait()
        if code != 0:
            raise RuntimeError(f"{label} failed with exit code {code}")

    def start(self) -> None:
        if self.started:
            return
        self.started = True
        threading.Thread(target=self.worker, daemon=True).start()

    def worker(self) -> None:
        try:
            if os.name != "nt":
                raise RuntimeError("This local launcher is currently Windows-only. Use the Streamlit app directly on non-Windows systems.")
            ensure_user_workspace()
            save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
            self.after(0, self.refresh_workspace_message)
            self.set_status("Checking app files", "Looking for the Pathmark app files.", 18, 1)
            if not APP_FILE.exists():
                raise FileNotFoundError(f"Missing app file: {APP_FILE}")
            if not REQUIREMENTS.exists():
                raise FileNotFoundError(f"Missing requirements file: {REQUIREMENTS}")

            self.set_status("Checking Python", "Pathmark uses Python to run the local app.", 30, 2)
            py_cmd = self.choose_python()

            self.set_status("Creating local environment", "This is only needed the first time the app is run.", 46, 3)
            if not VENV_PYTHON.exists():
                self.run_and_log(py_cmd + ["-m", "venv", str(VENV)], "Create environment")

            self.set_status("Installing app requirements", "This may take a minute the first time.", 62, 3)
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], "Upgrade pip")
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], "Install requirements")

            if not self.port_free(DEFAULT_PORT):
                self.port = DEFAULT_PORT
                self.set_status("Pathmark is already running", f"Opening the existing app at {self.current_url()}", 100, 4)
                self.after(350, lambda: webbrowser.open(self.current_url()))
                self.after(0, lambda: self.open_btn.config(state="normal"))
                return

            self.port = DEFAULT_PORT
            self.set_status("Starting Pathmark", "Opening the local app in your browser.", 84, 4)
            self.proc = subprocess.Popen(
                [
                    str(VENV_PYTHON), "-m", "streamlit", "run", str(APP_FILE),
                    "--server.port", str(self.port),
                    "--server.headless", "true",
                    "--browser.gatherUsageStats", "false",
                ],
                cwd=ROOT,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                creationflags=CREATE_NO_WINDOW,
                env=self.streamlit_env(),
            )
            self.after(1400, lambda: webbrowser.open(self.current_url()))
            self.after(0, lambda: (
                self.set_status("Pathmark is running", f"The app is open at {self.current_url()}", 100, 4),
                self.open_btn.config(state="normal"),
                self.stop_btn.config(state="normal"),
            ))
            assert self.proc.stdout is not None
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except FileNotFoundError as exc:
            self.log(str(exc))
            self.set_status("Python is needed", "Install Python 3.11 or later, then open Pathmark again.", 100)
            messagebox.showerror("Python is needed", "Python 3 was not found. Please install Python 3.11 or later, then open Pathmark again.")
            webbrowser.open("https://www.python.org/downloads/")
        except Exception as exc:
            self.log(str(exc))
            self.set_status("Pathmark could not start", str(exc), 100)
            messagebox.showerror("Pathmark could not start", str(exc))

    def show_details(self) -> None:
        win = tk.Toplevel(self)
        win.title("Pathmark details")
        win.geometry("820x480")
        text = ScrolledText(win, wrap="word")
        text.pack(fill="both", expand=True)
        text.insert("1.0", "\n".join(self.logs))
        text.config(state="disabled")

    def backup_local_data(self) -> Path | None:
        if self.needs_workspace_choice:
            self.prompt_workspace_choice()
            return None
        try:
            USER_BACKUPS.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            backup_path = USER_BACKUPS / f"pathmark_launcher_backup_{stamp}.zip"
            with zipfile.ZipFile(backup_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
                if USER_DB.exists():
                    z.write(USER_DB, "pathmark.db")
                if LAUNCHER_CONFIG.exists():
                    z.write(LAUNCHER_CONFIG, "pathmark_launcher_settings.json")
                workspace_launcher_settings = USER_SYSTEM / "pathmark_launcher_settings.json"
                if workspace_launcher_settings.exists():
                    z.write(workspace_launcher_settings, "workspace_pathmark_launcher_settings.json")
                z.writestr("README.txt", f"Backup created by the Pathmark launcher before updating.\nExpected Pathmark folder: {USER_ROOT}\nTheme at launcher setup: {self.theme_preset} / {self.theme_mode}\n")
            self.log(f"Backup created: {backup_path}")
            messagebox.showinfo("Backup created", f"Backup created:\n{backup_path}")
            return backup_path
        except Exception as exc:
            self.log(f"Backup failed: {exc}")
            messagebox.showerror("Backup failed", str(exc))
            return None

    def check_for_updates(self) -> None:
        webbrowser.open(RELEASE_HUB_URL)

    def backup_and_check_for_updates(self) -> None:
        self.backup_local_data()
        messagebox.showinfo("Update hub", "A backup has been created. The Pathmark update hub will now open. Download the new package, then replace only the Pathmark_app folder in your app location.")
        webbrowser.open(RELEASE_HUB_URL)

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.destroy()

    def on_close(self) -> None:
        self.stop_app()


if __name__ == "__main__":
    Launcher().mainloop()
