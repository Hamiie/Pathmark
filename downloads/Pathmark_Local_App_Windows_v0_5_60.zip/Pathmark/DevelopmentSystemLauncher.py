from __future__ import annotations

import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time
import zipfile
import webbrowser
import urllib.request
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import ttk

APP_NAME = "Pathmark"
APP_VERSION = "Local App v0.5.60"
WINDOWS_ONLY = True
DEFAULT_PORT = 8545
THEME_PRESETS = ["Default", "Seasonal", "Persimmon", "Marigold", "Moss", "Lagoon", "Iris", "Rosewood"]
THEME_MODES = ["Light", "Dark"]
RELEASE_HUB_URL = "https://pathmark.streamlit.app/"
RELEASE_VERSION_URL = "https://raw.githubusercontent.com/hamishtildesley1996/development-system-demo/main/latest_version.json"

THEME_SWATCHES = {
    "Default": ("#334E68", "#E7EEF4"),
    "Seasonal": ("#A66A43", "#F1E6DA"),
    "Persimmon": ("#B9633E", "#F3E1D6"),
    "Marigold": ("#A87913", "#F4E9C8"),
    "Moss": ("#60754A", "#E2E8D8"),
    "Lagoon": ("#357177", "#DDECEE"),
    "Iris": ("#6A5A96", "#E7E2F1"),
    "Rosewood": ("#8B4A55", "#EEDDE0"),
}


def app_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def documents_base() -> Path:
    candidates: list[Path] = []
    for key in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        value = os.environ.get(key)
        if value:
            candidates.append(Path(value) / "Documents")
    candidates.append(Path.home() / "OneDrive" / "Documents")
    candidates.append(Path.home() / "Documents")
    for candidate in candidates:
        try:
            if candidate.exists():
                return candidate
        except Exception:
            pass
    return Path.home() / "Documents"


def default_workspace_root() -> Path:
    return documents_base() / "Workspace"


def likely_workspace_root() -> Path:
    root = app_root()
    try:
        if root.name.lower() == "pathmark" and root.parent.name.lower() == "workspace":
            return root.parent
    except Exception:
        pass
    return default_workspace_root()


ROOT = app_root()
LAUNCHER_CONFIG = ROOT / "config" / "launcher_settings.json"
APP_FILE = ROOT / "app" / "main.py"
REQUIREMENTS = ROOT / "requirements.txt"
VENV = ROOT / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"
ICON = ROOT / "assets" / "pathmark.ico"
ICON_PNG = ROOT / "assets" / "pathmark.png"
CREATE_NO_WINDOW = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def load_launcher_config() -> dict:
    try:
        if LAUNCHER_CONFIG.exists():
            return json.loads(LAUNCHER_CONFIG.read_text(encoding="utf-8")) or {}
    except Exception:
        pass
    return {}


def load_configured_user_root() -> Path:
    data = load_launcher_config()
    value = data.get("workspace_root") or data.get("pathmark_root")
    if value:
        return Path(value).expanduser()
    return likely_workspace_root()


def normalise_preset(value: str | None) -> str:
    value = (value or "Default").strip()
    if value in ("Pathmark", "Custom"):
        value = "Default"
    return value if value in THEME_PRESETS else "Default"


def load_configured_theme() -> tuple[str, str]:
    data = load_launcher_config()
    preset = normalise_preset(data.get("theme_preset"))
    mode = data.get("theme_mode") or "Light"
    if mode not in THEME_MODES:
        mode = "Light"
    return preset, mode


def parse_version(value: str | None) -> tuple[int, ...]:
    text = (value or "").strip().lower().replace("local app", "").replace("version", "")
    text = text.lstrip("v").strip()
    parts: list[int] = []
    current = ""
    for char in text:
        if char.isdigit():
            current += char
        elif current:
            parts.append(int(current))
            current = ""
    if current:
        parts.append(int(current))
    return tuple(parts or [0])


def installed_version_info() -> dict:
    path = ROOT / "latest_version.json"
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8")) or {}
        except Exception:
            pass
    return {"version": APP_VERSION.replace("Local App ", "")}


def fetch_latest_version_info(timeout: int = 8) -> dict:
    with urllib.request.urlopen(RELEASE_VERSION_URL, timeout=timeout) as response:
        body = response.read().decode("utf-8")
    return json.loads(body)


def save_launcher_config(path: Path | None = None, theme_preset: str | None = None, theme_mode: str | None = None) -> None:
    data = load_launcher_config()
    if path is not None:
        data["workspace_root"] = str(path)
        data["pathmark_root"] = str(path)
    if theme_preset is not None:
        data["theme_preset"] = normalise_preset(theme_preset)
    if theme_mode is not None:
        data["theme_mode"] = theme_mode if theme_mode in THEME_MODES else "Light"
    LAUNCHER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    LAUNCHER_CONFIG.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        if path is not None:
            system = Path(path).expanduser() / "00_System"
            system.mkdir(parents=True, exist_ok=True)
            (system / "pathmark_launcher_settings.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


def set_user_root(path: Path) -> None:
    global USER_ROOT, USER_SYSTEM, USER_DB, USER_BACKUPS
    USER_ROOT = path.expanduser()
    USER_SYSTEM = USER_ROOT / "00_System"
    USER_DB = USER_SYSTEM / "pathmark.db"
    USER_BACKUPS = USER_SYSTEM / "Backups" / "Updates"


def ensure_user_workspace() -> None:
    USER_ROOT.mkdir(parents=True, exist_ok=True)
    for folder in (
        USER_SYSTEM,
        USER_SYSTEM / "Google Calendar Exports",
        USER_SYSTEM / "Google Tasks Exports",
        USER_SYSTEM / "Tasklists",
        USER_SYSTEM / "Backups",
    ):
        folder.mkdir(parents=True, exist_ok=True)
    readme = USER_ROOT / "README - Pathmark workspace.md"
    if not readme.exists():
        readme.write_text("""# Pathmark workspace

This is the workspace folder Pathmark uses for projects, numbered Area folders, exports, tasklists, backups, and the local database.

Keep this workspace when updating Pathmark. Replace only the separate `Pathmark` app folder.

## Area folder naming

Pathmark treats top-level folders as Areas only when they start with a two-digit number and an underscore, for example:

```text
01_Body_And_Stability
02_Home_And_Garden
03_Making_And_Craft
```

Ordinary unnumbered folders are ignored. This lets you keep other working files in the Workspace without turning them into Areas.

`00_System` is reserved for Pathmark's database, exports, backups, and system files.

When you add a new Area in the app, Pathmark suggests the next number automatically.
""", encoding="utf-8")


USER_ROOT = load_configured_user_root()
USER_SYSTEM = USER_ROOT / "00_System"
USER_DB = USER_SYSTEM / "pathmark.db"
USER_BACKUPS = USER_SYSTEM / "Backups" / "Updates"


class RoundedButton(tk.Canvas):
    def __init__(self, parent, text, command, *, primary=False, disabled=False, palette=None, min_width=150, height=46, accent=None, soft=None):
        self.palette = palette or {}
        self.command = command
        self.primary = primary
        self.selected = primary
        self.disabled = disabled
        self.text_value = text
        self.height_value = height
        self.min_width = min_width
        self.local_accent = accent
        self.local_soft = soft
        bg_parent = getattr(parent, "cget", lambda k: self.palette.get("surface", "#FFFFFF"))("bg")
        super().__init__(parent, height=height, width=min_width, bg=bg_parent, highlightthickness=0, bd=0, cursor="arrow" if disabled else "hand2")
        self.bind("<Button-1>", self._click)
        self.bind("<Enter>", lambda e: self._draw(hover=True))
        self.bind("<Leave>", lambda e: self._draw(hover=False))
        self.bind("<Configure>", lambda e: self._draw(False))
        self._draw(False)

    def config(self, cnf=None, **kw):
        if cnf:
            kw.update(cnf)
        if "state" in kw:
            self.disabled = kw.pop("state") == "disabled"
            self.configure(cursor="arrow" if self.disabled else "hand2")
        if "primary" in kw:
            self.primary = bool(kw.pop("primary"))
            self.selected = self.primary
        if "text" in kw:
            self.text_value = kw.pop("text")
        super().config(**kw)
        self._draw(False)

    configure = config

    def _round_rect(self, x1, y1, x2, y2, radius=18, **kwargs):
        points = [
            x1+radius, y1, x2-radius, y1, x2, y1, x2, y1+radius,
            x2, y2-radius, x2, y2, x2-radius, y2, x1+radius, y2,
            x1, y2, x1, y2-radius, x1, y1+radius, x1, y1,
        ]
        return self.create_polygon(points, smooth=True, **kwargs)

    def set_selected(self, selected: bool) -> None:
        self.selected = selected
        self.primary = selected
        self._draw(False)

    def _colours(self, hover=False):
        p = self.palette
        accent = self.local_accent or p.get("accent", "#334E68")
        soft = self.local_soft or p.get("surface2", "#EFEEE8")
        if self.disabled:
            return p.get("surface2", "#EFEEE8"), p.get("soft", "#8A8F8B"), p.get("surface2", "#EFEEE8")
        if self.primary or self.selected:
            return accent, "#FFFFFF", accent
        return (soft if not hover else "#F4F2EC"), p.get("text", "#151917"), p.get("line", "#D8D4CB")

    def _draw(self, hover=False):
        self.delete("all")
        w = max(self.winfo_width(), self.min_width)
        h = max(self.winfo_height(), self.height_value)
        fill, fg, outline = self._colours(hover)
        self._round_rect(2, 2, w-2, h-2, radius=19, fill=fill, outline=outline)
        self.create_text(w/2, h/2, text=self.text_value, fill=fg, font=("Segoe UI", 10, "bold" if self.primary else "normal"))

    def _click(self, _event):
        if not self.disabled and self.command:
            self.command()


class RoundedCard(tk.Canvas):
    def __init__(self, parent, palette, radius=24):
        self.palette = palette
        self.radius = radius
        super().__init__(parent, bg=palette["bg"], highlightthickness=0, bd=0)
        self.body = tk.Frame(self, bg=palette["surface"])
        self.window = self.create_window((2, 2), window=self.body, anchor="nw")
        self.bind("<Configure>", self._resize)
        self.body.bind("<Configure>", self._resize_to_content)

    def _round_rect(self, x1, y1, x2, y2, radius=24, **kwargs):
        points = [
            x1+radius, y1, x2-radius, y1, x2, y1, x2, y1+radius,
            x2, y2-radius, x2, y2, x2-radius, y2, x1+radius, y2,
            x1, y2, x1, y2-radius, x1, y1+radius, x1, y1,
        ]
        return self.create_polygon(points, smooth=True, **kwargs)

    def _resize(self, _event=None):
        w = max(self.winfo_width(), 200)
        h = max(self.winfo_height(), self.body.winfo_reqheight() + 4)
        self.delete("card")
        self._round_rect(1, 1, w-1, h-1, self.radius, fill=self.palette["surface"], outline=self.palette["line"], tags="card")
        self.tag_lower("card")
        self.itemconfig(self.window, width=max(1, w-4))

    def _resize_to_content(self, _event=None):
        required = self.body.winfo_reqheight() + 4
        if abs(int(self.cget("height") or 0) - required) > 2:
            self.configure(height=required)
        self._resize()


class Launcher(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1040x780")
        self.minsize(760, 600)
        self.proc: subprocess.Popen | None = None
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.logs: list[str] = []
        self.port = DEFAULT_PORT
        self.started = False
        # Keep the launcher itself simple and consistent. Theme customisation is handled inside Pathmark.
        self.theme_preset, self.theme_mode = "Default", "Light"
        self.palette = self.make_palette("Light")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        if ICON.exists():
            try:
                self.iconbitmap(default=str(ICON))
            except Exception:
                try:
                    self.iconbitmap(str(ICON))
                except Exception:
                    pass
        self.configure(bg=self.palette["bg"])
        self._style()
        self._build_scrollable_ui()
        self.after(150, self.drain_log)
        self.after(250, lambda: self.set_status("Ready to open Pathmark", "Confirm the Workspace, then choose Open Pathmark.", 8, 0))

    def make_palette(self, mode: str) -> dict:
        if mode == "Dark":
            return {
                "bg": "#161917", "hero": "#111412", "surface": "#20241F", "surface2": "#2A2E28",
                "text": "#F4F1EA", "muted": "#C0BDB4", "soft": "#8F948D", "accent": "#86A5C0",
                "accent_hover": "#6B8EAE", "accent_soft": "#263443", "warm": "#C68455", "line": "#393D36",
                "success": "#17311F", "success_text": "#CBE8D2", "input": "#F7F6F2"
            }
        return {
            "bg": "#F7F6F2", "hero": "#FBFAF7", "surface": "#FFFFFF", "surface2": "#EFEEE8",
            "text": "#151917", "muted": "#626966", "soft": "#818783", "accent": "#334E68",
            "accent_hover": "#253E54", "accent_soft": "#E7EEF4", "warm": "#A66A43", "line": "#D8D4CB",
            "success": "#E8F4EA", "success_text": "#255833", "input": "#FFFFFF"
        }

    def _style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Pathmark.Horizontal.TProgressbar", troughcolor=self.palette["surface2"], background=self.palette["warm"], bordercolor=self.palette["surface2"], lightcolor=self.palette["warm"], darkcolor=self.palette["warm"], thickness=10)

    def _button(self, parent, text, command, *, primary=False, disabled=False, min_width=150, accent=None, soft=None):
        return RoundedButton(parent, text, command, primary=primary, disabled=disabled, palette=self.palette, min_width=min_width, accent=accent, soft=soft)

    def _logo(self, parent, size=46):
        holder = tk.Frame(parent, bg=self.palette["hero"], width=size, height=size)
        holder.pack_propagate(False)
        self.logo_image = None
        if ICON_PNG.exists():
            try:
                raw = tk.PhotoImage(file=str(ICON_PNG))
                factor = max(1, min(raw.width() // size, raw.height() // size))
                self.logo_image = raw.subsample(factor, factor)
                tk.Label(holder, image=self.logo_image, bg=self.palette["hero"]).pack(expand=True)
                return holder
            except Exception:
                pass
        c = tk.Canvas(holder, width=size, height=size, bg=self.palette["hero"], highlightthickness=0)
        c.create_rectangle(3, 3, size - 3, size - 3, fill="#182A27", outline="")
        c.create_line(size*.26, size*.68, size*.43, size*.50, size*.58, size*.57, size*.74, size*.34, fill="#F6F4EF", width=max(3, size//10), smooth=True)
        c.pack(expand=True)
        return holder

    def _build_scrollable_ui(self) -> None:
        self.canvas = tk.Canvas(self, bg=self.palette["bg"], highlightthickness=0)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.content = tk.Frame(self.canvas, bg=self.palette["bg"])
        self.window_id = self.canvas.create_window((0, 0), window=self.content, anchor="nw")
        self.content.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfig(self.window_id, width=e.width))
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self._build_ui(self.content)

    def _on_mousewheel(self, event) -> None:
        try:
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def _section_card(self, parent, title: str, body: str) -> RoundedCard:
        card = RoundedCard(parent, self.palette)
        tk.Label(card.body, text=title, bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 16, "bold"), anchor="w").pack(fill="x", padx=26, pady=(24, 5))
        tk.Label(card.body, text=body, bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 10), anchor="w", wraplength=880, justify="left").pack(fill="x", padx=26, pady=(0, 18))
        return card

    def _build_ui(self, outer) -> None:
        hero = tk.Frame(outer, bg=self.palette["hero"])
        hero.pack(fill="x")
        inner = tk.Frame(hero, bg=self.palette["hero"])
        inner.pack(fill="x", padx=48, pady=(28, 30))
        self._logo(inner, 46).pack(anchor="w", pady=(0, 22))
        tk.Label(inner, text="Local app launcher", bg=self.palette["accent_soft"], fg=self.palette["accent"], padx=12, pady=6, font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(0, 12))
        tk.Label(inner, text="Pathmark", font=("Segoe UI Variable Display", 52, "bold"), fg=self.palette["text"], bg=self.palette["hero"], anchor="w").pack(fill="x")
        tk.Label(inner, text="Make time for routines. Reduce friction with prompts. Keep goals moving.", font=("Segoe UI", 11, "bold"), fg=self.palette["text"], bg=self.palette["hero"], anchor="w").pack(fill="x", pady=(8, 0))

        body = tk.Frame(outer, bg=self.palette["bg"])
        body.pack(fill="both", expand=True, padx=42, pady=(22, 30))

        intro = RoundedCard(body, self.palette)
        intro.body.configure(bg=self.palette["success"])
        intro.pack(fill="x", pady=(0, 16))
        tk.Label(intro.body, text="Set the Workspace before opening the app", bg=self.palette["success"], fg=self.palette["success_text"], font=("Segoe UI", 13, "bold"), anchor="w").pack(fill="x", padx=24, pady=(18, 4))
        tk.Label(intro.body, text="The Workspace is where Pathmark keeps your numbered Area folders, exports, tasklists, backups, and local database. The default is Documents\\Workspace. Choose an existing folder here if you already have one.", bg=self.palette["success"], fg=self.palette["success_text"], font=("Segoe UI", 10), anchor="w", wraplength=900, justify="left").pack(fill="x", padx=24, pady=(0, 18))

        workspace_card = self._section_card(body, "1. Workspace", "Use Documents\\Workspace or point Pathmark to an existing project folder before opening the app. Pathmark creates system folders only inside the selected Workspace.")
        workspace_card.pack(fill="x", pady=(0, 16))
        form = tk.Frame(workspace_card.body, bg=self.palette["surface"])
        form.pack(fill="x", padx=26, pady=(0, 22))
        form.grid_columnconfigure(1, weight=1)
        tk.Label(form, text="Workspace folder", bg=self.palette["surface"], fg=self.palette["text"], font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w", padx=(0, 12), pady=6)
        self.workspace_var = tk.StringVar(value=str(USER_ROOT))
        self.workspace_entry = tk.Entry(form, textvariable=self.workspace_var, bg=self.palette["input"], fg="#151917", relief="flat", bd=0, font=("Segoe UI", 10), highlightthickness=1, highlightbackground=self.palette["line"], highlightcolor=self.palette["accent"])
        self.workspace_entry.grid(row=0, column=1, sticky="ew", pady=6, ipady=10)
        self._button(form, "Browse", self.choose_workspace_folder, min_width=130).grid(row=0, column=2, sticky="ew", padx=(12, 0), pady=6)
        self._button(form, "Save", self.save_workspace_from_entry, min_width=130).grid(row=0, column=3, sticky="ew", padx=(8, 0), pady=6)
        self.workspace_text = tk.Label(workspace_card.body, text=self.workspace_message(), bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9), anchor="w", wraplength=900, justify="left")
        self.workspace_text.pack(fill="x", padx=26, pady=(0, 20))

        action_card = self._section_card(body, "2. Open or check for updates", "Open Pathmark when you are ready. Check for updates compares this app folder with the release hub, then opens the download page only when a newer version is available.")
        action_card.pack(fill="x", pady=(0, 16))
        actions = tk.Frame(action_card.body, bg=self.palette["surface"])
        actions.pack(fill="x", padx=21, pady=(0, 22))
        self.open_btn = self._button(actions, "Open Pathmark", self.start, primary=True)
        self.update_btn = self._button(actions, "Check for updates", self.check_for_updates)
        self.stop_btn = self._button(actions, "Stop app", self.stop_app, disabled=True)
        self.details_btn = self._button(actions, "Show details", self.show_details)
        for i, btn in enumerate([self.open_btn, self.update_btn, self.stop_btn, self.details_btn]):
            btn.grid(row=0, column=i, sticky="ew", padx=5, pady=5)
            actions.grid_columnconfigure(i, weight=1)
        tk.Label(action_card.body, text="Keep Documents\\Pathmark as the replaceable app folder. Keep the Workspace separate and do not replace it during updates.", bg=self.palette["surface"], fg=self.palette["muted"], font=("Segoe UI", 9), justify="left", anchor="w", wraplength=900).pack(fill="x", padx=26, pady=(0, 20))

        status_card = self._section_card(body, "Status", "Progress appears here while the local app is checked, installed, and opened.")
        status_card.pack(fill="x", pady=(0, 18))
        self.status = tk.Label(status_card.body, text="Ready", font=("Segoe UI Variable Display", 18, "bold"), fg=self.palette["text"], bg=self.palette["surface"], anchor="w")
        self.status.pack(fill="x", padx=26, pady=(0, 5))
        self.detail = tk.Label(status_card.body, text="Confirm your Workspace, then open Pathmark.", font=("Segoe UI", 10), fg=self.palette["muted"], bg=self.palette["surface"], anchor="w", wraplength=900, justify="left")
        self.detail.pack(fill="x", padx=26, pady=(0, 16))
        self.progress = ttk.Progressbar(status_card.body, style="Pathmark.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=26, pady=(0, 18))
        self.progress["value"] = 8
        self.step_labels = []
        steps = tk.Frame(status_card.body, bg=self.palette["surface"])
        steps.pack(fill="x", padx=26, pady=(0, 22))
        for label in ["Choose workspace", "Check files", "Check Python", "Prepare environment", "Start app"]:
            row = tk.Label(steps, text=f"○ {label}", fg=self.palette["soft"], bg=self.palette["surface"], font=("Segoe UI", 9), anchor="w")
            row.pack(fill="x", pady=2)
            self.step_labels.append(row)

    def workspace_message(self) -> str:
        return f"Current Workspace: {USER_ROOT}"

    def refresh_workspace_message(self) -> None:
        try:
            self.workspace_text.config(text=self.workspace_message())
            self.workspace_var.set(str(USER_ROOT))
        except Exception:
            pass

    def update_theme_preview(self) -> None:
        try:
            accent, soft = THEME_SWATCHES.get(self.theme_preset, THEME_SWATCHES["Default"])
            if self.theme_mode == "Dark":
                self.theme_preview.config(bg="#20241F", fg="#F4F1EA", text=f"{self.theme_preset} / Dark preview")
            else:
                self.theme_preview.config(bg=soft, fg=accent, text=f"{self.theme_preset} / Light preview")
        except Exception:
            pass

    def refresh_theme_chips(self) -> None:
        for name, btn in getattr(self, "theme_chip_buttons", {}).items():
            btn.set_selected(name == self.theme_preset)
        for name, btn in getattr(self, "mode_chip_buttons", {}).items():
            btn.set_selected(name == self.theme_mode)
        self.update_theme_preview()

    def choose_theme(self, name: str) -> None:
        self.theme_preset = normalise_preset(name)
        self.theme_var.set(self.theme_preset)
        self.refresh_theme_chips()

    def choose_mode(self, name: str) -> None:
        self.theme_mode = name if name in THEME_MODES else "Light"
        self.mode_var.set(self.theme_mode)
        self.refresh_theme_chips()

    def save_theme_choice(self) -> None:
        self.theme_preset = normalise_preset(self.theme_var.get() if hasattr(self, "theme_var") else self.theme_preset)
        self.theme_mode = self.mode_var.get() if hasattr(self, "mode_var") else self.theme_mode
        if self.theme_mode not in THEME_MODES:
            self.theme_mode = "Light"
        save_launcher_config(path=USER_ROOT, theme_preset=self.theme_preset, theme_mode=self.theme_mode)
        self.refresh_workspace_message()
        if hasattr(self, "theme_feedback"):
            self.theme_feedback.config(text=f"Saved: {self.theme_preset} / {self.theme_mode}")
        self.set_status("Theme saved", f"Pathmark will launch with {self.theme_preset} / {self.theme_mode} unless an already-running local app is still open.", 10, 0)

    def save_workspace_from_entry(self) -> None:
        raw = self.workspace_var.get().strip() if hasattr(self, "workspace_var") else ""
        if not raw:
            messagebox.showerror("Workspace required", "Please choose a workspace folder.")
            return
        self.set_workspace(Path(raw), start_after=False)

    def choose_workspace_folder(self) -> None:
        selected = filedialog.askdirectory(title="Choose the workspace Pathmark should use for projects and exports", initialdir=str(USER_ROOT if USER_ROOT.exists() else documents_base()))
        if selected:
            self.workspace_var.set(selected)
            self.set_workspace(Path(selected), start_after=False)

    def set_workspace(self, path: Path, *, start_after: bool = False) -> None:
        set_user_root(path)
        save_launcher_config(path=USER_ROOT)
        ensure_user_workspace()
        self.refresh_workspace_message()
        self.set_status("Workspace saved", f"Pathmark will use: {USER_ROOT}", 10, 0)
        if start_after and not self.started:
            self.after(150, self.start)

    def streamlit_env(self) -> dict[str, str]:
        env = os.environ.copy()
        env["PATHMARK_ROOT"] = str(USER_ROOT)
        env["PATHMARK_INITIAL_THEME_PRESET"] = "Default"
        env["PATHMARK_INITIAL_THEME_MODE"] = "Light"
        env["PATHMARK_LAUNCHER_CONFIG"] = str(LAUNCHER_CONFIG)
        env["PATHMARK_SYNC_THEME_FROM_LAUNCHER"] = "0"
        return env

    def current_url(self) -> str:
        return f"http://localhost:{self.port}"

    def mark_step(self, index: int) -> None:
        for i, lab in enumerate(self.step_labels):
            label_text = lab.cget("text").replace("○", "").replace("●", "").strip()
            lab.config(text=("● " if i <= index else "○ ") + label_text, fg=self.palette["accent"] if i < index else (self.palette["text"] if i == index else self.palette["soft"]))

    def set_status(self, status: str, detail: str = "", value: int | None = None, step: int | None = None) -> None:
        self.status.config(text=status)
        self.detail.config(text=detail or status)
        if value is not None:
            self.progress["value"] = value
        if step is not None:
            self.mark_step(step)
        self.update_idletasks()

    def log(self, text: str) -> None:
        self.logs.append(text)
        self.log_queue.put(text)

    def drain_log(self) -> None:
        try:
            while True:
                self.log_queue.get_nowait()
        except queue.Empty:
            pass
        self.after(250, self.drain_log)

    def choose_python(self) -> list[str]:
        for cmd in [["py", "-3"], ["python"]]:
            try:
                subprocess.run(cmd + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True, creationflags=CREATE_NO_WINDOW)
                return cmd
            except Exception:
                continue
        raise FileNotFoundError("Python 3 was not found.")

    def port_free(self, port: int) -> bool:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(0.2)
            return sock.connect_ex(("127.0.0.1", port)) != 0

    def run_and_log(self, args: list[str], label: str) -> None:
        self.log(f"$ {' '.join(args)}")
        proc = subprocess.Popen(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=CREATE_NO_WINDOW)
        assert proc.stdout is not None
        for line in proc.stdout:
            self.log(line.rstrip())
        code = proc.wait()
        if code != 0:
            raise RuntimeError(f"{label} failed with exit code {code}")

    def start(self) -> None:
        if self.started:
            webbrowser.open(self.current_url())
            return
        raw = self.workspace_var.get().strip() if hasattr(self, "workspace_var") else str(USER_ROOT)
        if not raw:
            messagebox.showerror("Workspace required", "Please choose a workspace folder.")
            return
        set_user_root(Path(raw))
        save_launcher_config(path=USER_ROOT)
        self.refresh_workspace_message()
        self.started = True
        self.open_btn.config(state="disabled")
        self.set_status("Opening Pathmark", "Setting up the Workspace and checking the local app.", 12, 0)
        threading.Thread(target=self.worker, daemon=True).start()

    def worker(self) -> None:
        try:
            if os.name != "nt":
                raise RuntimeError("This local launcher is currently Windows-only. Use the Streamlit app directly on non-Windows systems.")
            ensure_user_workspace()
            save_launcher_config(path=USER_ROOT)
            self.after(0, self.refresh_workspace_message)
            self.set_status("Checking app files", "Looking for the Pathmark app files.", 20, 1)
            if not APP_FILE.exists():
                raise FileNotFoundError(f"Missing app file: {APP_FILE}")
            if not REQUIREMENTS.exists():
                raise FileNotFoundError(f"Missing requirements file: {REQUIREMENTS}")
            self.set_status("Checking Python", "Pathmark uses Python to run the local app.", 34, 2)
            py_cmd = self.choose_python()
            self.set_status("Preparing the local environment", "This is only needed the first time this copy of Pathmark is run.", 48, 3)
            if not VENV_PYTHON.exists():
                self.run_and_log(py_cmd + ["-m", "venv", str(VENV)], "Create environment")
            self.set_status("Installing app requirements", "This may take a minute the first time.", 64, 3)
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "--upgrade", "pip"], "Upgrade pip")
            self.run_and_log([str(VENV_PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)], "Install requirements")
            if not self.port_free(DEFAULT_PORT):
                self.port = DEFAULT_PORT
                self.set_status("Pathmark is already running", f"Opening the existing app at {self.current_url()}.", 100, 4)
                self.after(350, lambda: webbrowser.open(self.current_url()))
                self.after(0, lambda: self.open_btn.config(state="normal", text="Open existing app"))
                return
            self.port = DEFAULT_PORT
            self.set_status("Starting Pathmark", "Opening the local app in your browser.", 84, 4)
            self.proc = subprocess.Popen([str(VENV_PYTHON), "-m", "streamlit", "run", str(APP_FILE), "--server.port", str(self.port), "--server.headless", "true", "--browser.gatherUsageStats", "false"], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, creationflags=CREATE_NO_WINDOW, env=self.streamlit_env())
            self.after(1400, lambda: webbrowser.open(self.current_url()))
            self.after(0, lambda: (self.set_status("Pathmark is running", f"The app is open at {self.current_url()}", 100, 4), self.open_btn.config(state="normal", text="Open Pathmark in browser"), self.stop_btn.config(state="normal")))
            assert self.proc.stdout is not None
            for line in self.proc.stdout:
                self.log(line.rstrip())
        except FileNotFoundError as exc:
            self.log(str(exc))
            self.set_status("Python is needed", "Install Python 3.11 or later, then open Pathmark again.", 100)
            messagebox.showerror("Python is needed", "Python 3 was not found. Please install Python 3.11 or later, then open Pathmark again.")
            webbrowser.open("https://www.python.org/downloads/")
            self.after(0, lambda: self.open_btn.config(state="normal"))
            self.started = False
        except Exception as exc:
            self.log(str(exc))
            self.set_status("Pathmark could not start", str(exc), 100)
            messagebox.showerror("Pathmark could not start", str(exc))
            self.after(0, lambda: self.open_btn.config(state="normal"))
            self.started = False

    def show_details(self) -> None:
        win = tk.Toplevel(self)
        win.title("Pathmark details")
        win.geometry("820x480")
        text = ScrolledText(win, wrap="word")
        text.pack(fill="both", expand=True)
        text.insert("1.0", "\n".join(self.logs) if self.logs else "No technical details yet.")
        text.config(state="disabled")

    def create_update_backup(self) -> Path | None:
        try:
            raw = self.workspace_var.get().strip() if hasattr(self, "workspace_var") else str(USER_ROOT)
            if raw:
                set_user_root(Path(raw))
            ensure_user_workspace()
            save_launcher_config(path=USER_ROOT)
            USER_BACKUPS.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y%m%d_%H%M%S")
            backup_path = USER_BACKUPS / f"pathmark_update_backup_{stamp}.zip"
            with zipfile.ZipFile(backup_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
                if USER_DB.exists():
                    z.write(USER_DB, "pathmark.db")
                if LAUNCHER_CONFIG.exists():
                    z.write(LAUNCHER_CONFIG, "pathmark_launcher_settings.json")
                workspace_launcher_settings = USER_SYSTEM / "pathmark_launcher_settings.json"
                if workspace_launcher_settings.exists():
                    z.write(workspace_launcher_settings, "workspace_pathmark_launcher_settings.json")
                z.writestr("README.txt", f"Backup created by Pathmark before updating.\nWorkspace: {USER_ROOT}\nTheme: {self.theme_preset} / {self.theme_mode}\n")
            self.log(f"Update backup created: {backup_path}")
            return backup_path
        except Exception as exc:
            self.log(f"Update backup failed: {exc}")
            messagebox.showerror("Update backup failed", str(exc))
            return None

    def check_for_updates(self) -> None:
        self.set_status("Checking for updates", "Comparing your installed version with the release hub.", 24, 0)
        try:
            installed = installed_version_info()
            latest = fetch_latest_version_info()
            installed_version = installed.get("version", "unknown")
            latest_version = latest.get("version", "unknown")
            if parse_version(latest_version) <= parse_version(installed_version):
                message = f"Installed version: {installed_version}\nLatest version: {latest_version}"
                self.set_status("Pathmark is up to date", message, 100, 0)
                messagebox.showinfo("Pathmark is up to date", message)
                return

            detail = (
                f"Installed version: {installed_version}\n"
                f"Latest version: {latest_version}\n\n"
                "Before updating, Pathmark can save an update backup of your Workspace settings and database. "
                "Then the download page will open. Replace only Documents\\Pathmark; keep your Workspace."
            )
            self.set_status("A newer version is available", detail, 100, 0)
            if messagebox.askyesno("A newer version of Pathmark is available", detail + "\n\nCreate backup and open the download page now?"):
                backup = self.create_update_backup()
                if backup:
                    self.set_status("Update backup created", f"Backup saved to {backup}. The download page is opening now.", 100, 0)
                webbrowser.open(RELEASE_HUB_URL)
        except Exception as exc:
            self.log(f"Update check failed: {exc}")
            self.set_status("Could not check for updates", f"Pathmark could not reach the release hub version file. {exc}", 100, 0)
            if messagebox.askyesno("Could not check for updates", "Pathmark could not check the latest version. Open the download page instead?"):
                webbrowser.open(RELEASE_HUB_URL)

    def stop_app(self) -> None:
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.destroy()

    def on_close(self) -> None:
        self.stop_app()


if __name__ == "__main__":
    Launcher().mainloop()
