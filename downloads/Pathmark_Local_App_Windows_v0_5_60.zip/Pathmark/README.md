# Pathmark Windows app source

Pathmark is a local Windows Streamlit app for organising goals, routines, areas, exports, and review prompts.

This package is currently Windows-only for the local launcher. Mac support has been removed for now so the Windows packaging and update workflow can stay simpler.

## Recommended local folder structure

Keep the replaceable app folder separate from the user's project/export workspace. This is closer to how desktop apps usually behave: the app files are replaceable, while user data stays in a separate workspace.

Recommended app location:

```text
Documents\Pathmark
```

The launcher then creates or points to the workspace folder:

```text
Documents\Workspace
├── 00_System
│   ├── pathmark.db
│   ├── Backups
│   ├── Tasklists
│   ├── Google Calendar Exports
│   └── Google Tasks Exports
├── 01_Body_And_Stability
├── 02_Home_And_Garden
└── 03_Making_And_Craft
```

The workspace can be changed from the launcher before starting Pathmark, or from **Settings → Setup and folders** later.

## Existing folders become Areas

Pathmark detects top-level folders in the selected Pathmark root and imports them as Areas. Numbered folders such as `01_Body_And_Stability` are supported, but numbering is not required.

The import is read-only. It does not delete, rename, move, or empty the user's folders.

Ignored folders include `00_System`, `Pathmark`, `Backups`, `Tasklists`, `Google Calendar Exports`, and `Google Tasks Exports`.

## Run locally without building the executable

Open a Command Prompt in this folder and run:

```text
run_app.bat
```

This starts Streamlit on port `8545` in headless mode so the launcher or browser controls when the app window opens.

## Build the Windows launcher

Run:

```text
build_launcher_exe.bat
```

This creates:

```text
Pathmark.exe
```

Use `Start Pathmark.cmd` as the fallback if the executable has not been built yet.

## Launcher behaviour

The launcher now:

- uses the same Pathmark branding as the app
- starts Streamlit in headless mode
- reuses the existing app on port `8545` rather than opening a second local app window
- creates the default `Documents\Workspace` workspace if needed
- lets the user choose the workspace folder before opening the app
- explains that this workspace is used for projects, area folders, exports, tasklists, backups, and the local database
- includes a single `Check for updates` action, which creates an update backup and opens the update hub

## Updating Pathmark

Before replacing the app folder, use the launcher action:

```text
Update
```

Then replace only the app files/folder. Do not replace the user's workspace folder, `00_System`, export folders, backups, or Area folders.

## GitHub upload note

For a GitHub repository, upload the contents of this folder as the repository root.

Do not upload local-only files such as `.venv`, `__pycache__`, `Pathmark.exe`, `00_System`, `data`, `output`, or generated exports.


## v0.5.60

This release simplifies setup and workflow: the launcher focuses on the Workspace and update checks, the app handles themes, the sidebar follows the main workflow, Areas hide folder/Markdown internals, and goals/routines quietly maintain their Workspace files when saved.
