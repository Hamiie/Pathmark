@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo Pathmark v0.5.60
echo --------------------------------
echo Streamlit port: 8545
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    set PYTHON_CMD=py
) else (
    where python >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        set PYTHON_CMD=python
    ) else (
        echo Python was not found. Please install Python, then run this file again.
        pause
        exit /b 1
    )
)

if not exist "requirements.txt" (
    echo requirements.txt was not found.
    echo Make sure you are running this file from the project folder.
    pause
    exit /b 1
)

echo Checking requirements...
!PYTHON_CMD! -m pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Requirement installation failed.
    pause
    exit /b 1
)

echo.
echo Starting Pathmark v0.5.60 on port 8545...
echo Close this window or press Ctrl+C to stop the app.
echo.
!PYTHON_CMD! -m streamlit run app\main.py --server.port 8545 --server.headless true --browser.gatherUsageStats false
set APP_EXIT=%ERRORLEVEL%
if %APP_EXIT% NEQ 0 (
    echo.
    echo The app stopped with an error.
    pause
    exit /b %APP_EXIT%
)
exit /b 0
