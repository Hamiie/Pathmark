# v0.7.25 — Shared ingredient catalogue and user overrides

- Reads shared ingredient reference data from Supabase where configured.
- Adds user-owned ingredient override rows in Pathmark Sync.
- Shows ingredient source badges: Pathmark data, Your data, Not matched.
- Keeps seasonality and nutrition reference data out of the user sheet unless customised.
