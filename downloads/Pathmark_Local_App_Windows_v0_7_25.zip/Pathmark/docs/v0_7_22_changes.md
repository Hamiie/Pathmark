# v0.7.22 — Architecture and performance foundation

- Render one selected top-level section at a time instead of all tab bodies.
- Render one selected Planning section and one selected Nutrition section at a time.
- Add developer performance diagnostics for reruns, Sheets reads/writes, cache hits and dirty session changes.
- Add foundation modules under app/core, app/data and app/components for future modularisation.
- Keep shopping trolley interactions local-first with explicit Save changes.
