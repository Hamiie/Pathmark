# v0.7.21 — Shopping trolley and recipe search cleanup

- Renamed completed shopping items to In trolley.
- Added Add trolley to inventory.
- Moved expiry/reminder workflow to Inventory.
- Removed duplicate Meal category filter from Recipe Finder.
- Added multi-select filters, include/exclude terms and advanced Boolean-style recipe search.
