# Pathmark v0.7.30 — Ingredient conversions and recipe alternatives

This release adds the hosted Pathmark foundations for a cleaner ingredient model:

- ingredient-specific volume, count and household-measure conversions
- user-owned conversion rows in Pathmark Sync
- structured recipe ingredient groups and options
- recipe alternatives that flow into shopping lists
- shopping-list alternative selection before trolley items are added to inventory
- inventory inflows based on the item actually selected or bought

Existing recipe ingredient rows remain compatible.
