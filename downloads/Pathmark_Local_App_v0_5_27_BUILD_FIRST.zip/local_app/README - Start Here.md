# Start Here

## 1. Build the launcher

Run:

```text
build_launcher_exe.bat
```

This creates:

```text
Start Pathmark.exe
```

## 2. Start Pathmark

Open:

```text
Start Pathmark.exe
```

If the executable has not been created yet, use the fallback launcher:

```text
Start Pathmark.cmd
```

## 3. Choose where Pathmark should keep your system

For a new setup, the recommended folder is:

```text
Documents\Pathmark
```

You can choose another folder if you already have an existing system.

## Safety

Pathmark creates missing folders and files only. It does not delete your existing files. When it updates planning files, it creates backups first.
