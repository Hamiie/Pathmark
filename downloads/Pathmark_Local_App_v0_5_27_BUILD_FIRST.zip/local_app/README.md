# Pathmark Local App Package

This package contains the local Pathmark app.

## Build the launcher first

Before using this package as a Windows app, run:

```text
build_launcher_exe.bat
```

This creates:

```text
Start Pathmark.exe
```

The fallback launcher is:

```text
Start Pathmark.cmd
```

## Start Pathmark

After the launcher has been built, open:

```text
Start Pathmark.exe
```

Pathmark will open locally in your browser and ask where it should keep your system. The recommended folder for a new setup is:

```text
Documents\Pathmark
```

Pathmark creates missing folders and files only. It does not delete your existing files. Markdown/planning files are backed up before they are updated.
