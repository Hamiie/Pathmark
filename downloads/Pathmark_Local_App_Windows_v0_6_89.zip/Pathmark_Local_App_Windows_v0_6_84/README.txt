Pathmark Local App Windows v0.6.84

This package accompanies the hosted release hub. The hosted Shopping List beta changes are in app/main.py.
