# v0.7.26 — Navigation shell and Pathmark Home

- Adds a signed-in Pathmark Home hub.
- Planning, Nutrition and Finance now open as focused workspaces.
- Removes the signed-in top-level tab row from inside workspace use.
- Adds a simple return action back to Pathmark Home.
- Moves Theme, About & Privacy, Public Home/Download and Developer into utility actions from the hub.
