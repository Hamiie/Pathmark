# v0.7.29 — Loading states and interaction guard

- Adds quiet loading status feedback when moving from Pathmark Home into Planning, Nutrition or Finance.
- Applies the same native transition message to utility pages such as Appearance, About & Privacy, Public Home / Download and Developer.
- Keeps workspace tiles and workspace switcher controls on native Streamlit state navigation.
- Disables repeated navigation actions when a Pathmark transition is marked as loading.
- Does not add mobile viewport hacks, PWA support, or new Supabase migrations.
