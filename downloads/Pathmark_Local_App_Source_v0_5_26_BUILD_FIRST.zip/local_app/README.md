# Pathmark Local App Source

This package contains the local Pathmark app source. It does not include a prebuilt EXE.

Run `build_launcher_exe.bat` on Windows first to create `Start Pathmark.exe`, then run `package_for_cloud_download.bat` to create the friend-facing app zip.

For new installs, the recommended root folder is `Documents\Pathmark`. Existing users may choose an older `Documents\Development` folder if needed.
