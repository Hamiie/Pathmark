# Pathmark Local App v0.7.28

Native workspace navigation fix.
