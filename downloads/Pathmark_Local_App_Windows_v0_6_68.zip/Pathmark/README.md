# Pathmark Local App

Bundled with hosted release v0.6.66 Google permissions onboarding and sync diagnostics.

# Pathmark Local App

## v0.6.27

This local Windows package is included for release completeness. The v0.6.27 finance rebuild applies to the hosted Pathmark Online release hub.

# Pathmark Windows app source

Pathmark is a local Windows Streamlit app for organising goals, routines, areas, exports, and review prompts.

This package is currently Windows-only for the local launcher. Mac support has been removed for now so the Windows packaging and update workflow can stay simpler.

## Recommended local folder structure

Keep the replaceable app folder separate from the user's project/export workspace. This is closer to how desktop apps usually behave: the app files are replaceable, while user data stays in a separate workspace.

Recommended app location:

```text
Documents\Pathmark
```

The launcher then creates or points to the workspace folder:

```text
Documents\Workspace
├── 00_System
│   ├── pathmark.db
│   ├── Backups
│   ├── Tasklists
│   ├── Google Calendar Exports
│   └── Google Tasks Exports
├── 01_Body_And_Stability
├── 02_Home_And_Garden
└── 03_Making_And_Craft
```

The workspace can be changed from the launcher before starting Pathmark, or from **Settings → Setup and folders** later.

## Existing folders become Areas

Pathmark detects top-level folders in the selected Pathmark root and imports them as Areas. Numbered folders such as `01_Body_And_Stability` are supported, but numbering is not required.

The import is read-only. It does not delete, rename, move, or empty the user's folders.

Ignored folders include `00_System`, `Pathmark`, `Backups`, `Tasklists`, `Google Calendar Exports`, and `Google Tasks Exports`.

## Run locally without building the executable

Open a Command Prompt in this folder and run:

```text
run_app.bat
```

This starts Streamlit on port `8545` in headless mode so the launcher or browser controls when the app window opens.

## Build the Windows launcher

Run:

```text
build_launcher_exe.bat
```

This creates:

```text
Pathmark.exe
```

Use `Start Pathmark.cmd` as the fallback if the executable has not been built yet.

## Launcher behaviour

The launcher now:

- uses the same Pathmark branding as the app
- starts Streamlit in headless mode
- reuses the existing app on port `8545` rather than opening a second local app window
- creates the default `Documents\Workspace` workspace if needed
- lets the user choose the workspace folder before opening the app
- explains that this workspace is used for projects, area folders, exports, tasklists, backups, and the local database
- includes a single `Check for updates` action, which creates an update backup and opens the update hub

## Updating Pathmark

Before replacing the app folder, use the launcher action:

```text
Update
```

Then replace only the app files/folder. Do not replace the user's workspace folder, `00_System`, export folders, backups, or Area folders.

## GitHub upload note

For a GitHub repository, upload the contents of this folder as the repository root.

Do not upload local-only files such as `.venv`, `__pycache__`, `Pathmark.exe`, `00_System`, `data`, `output`, or generated exports.


## v0.5.72

This release simplifies setup and workflow: the launcher focuses on the Workspace and update checks, the app handles themes, the sidebar follows the main workflow, Areas hide folder/Markdown internals, and goals/routines quietly maintain their Workspace files when saved.


## v0.5.72

This release adds optional user-authorised Google Sheets OAuth for on-the-go capture and desktop sync. CSV import/export remains available as the simplest workflow. The desktop OAuth token is stored in the Workspace system folder, not in the replaceable app folder.


## On-the-go Google Sheets sync

Pathmark uses user-authorised OAuth for Google Sheets sync. The hosted app and desktop app request the narrower Google `drive.file` permission so they can work with the Pathmark sync sheet used by the app, rather than asking for access to every spreadsheet in the user's Google account. CSV import remains available as the safest fallback.


## v0.5.74

Hosted release hub update: Supabase access management now prefers Secret API keys (`sb_secret_...`) instead of legacy service-role keys. The local desktop app is otherwise unchanged from v0.5.72.


## v0.5.83 hosted update

The hosted Pathmark release hub now treats Google login as the entry point for Pathmark Online and the user-owned Google sync sheet. The local desktop app remains the Workspace, Markdown, backup, and export publisher.


## v0.5.93

This package accompanies the hosted Pathmark Online v0.5.93 release. Local desktop functionality is unchanged in this release.


## v0.5.93

This package accompanies the hosted Pathmark Online v0.5.93 release. Local desktop functionality is unchanged in this release.

## v0.5.94

This package accompanies the hosted Pathmark Online v0.5.94 release. Local desktop functionality is unchanged in this release.


## v0.5.97

Hosted Pathmark Online guided setup refinement. Local desktop behaviour is unchanged.


## v0.6.0
- Hosted Pathmark Online setup, privacy, weekly focus and hint refinements.

## v0.5.98

- Metadata update for the Pathmark Online guided setup polish release.


## v0.6.33 Spending Plan bucket and inline save refinement

- Reworked Spending Plan spending setup into a guided checklist grouped by money-flow role.
- Custom spending items now start with the item name and suggest a money-flow destination.


## v0.6.33 Spending Plan save refresh repair

This local package accompanies the hosted release. The hosted Spending Plan save flow now refreshes newly saved rows without requiring logout.

## v0.6.61 Google security guardrails

Adds clearer Google security and consent guardrails, optional Tasks/Calendar scope prompts at the point of use, and safety-backup options before sync actions.
