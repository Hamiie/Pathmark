@echo off
setlocal
cd /d "%~dp0"
title Build Pathmark

echo Building Pathmark.exe...
echo Delete any existing Pathmark.exe first if you want to be certain the launcher is rebuilt.
echo.

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -m pip install --upgrade pip pyinstaller
  py -m PyInstaller --onefile --noconsole --name "Pathmark" --icon "assets\pathmark.ico" DevelopmentSystemLauncher.py
  goto done
)

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  python -m pip install --upgrade pip pyinstaller
  python -m PyInstaller --onefile --noconsole --name "Pathmark" --icon "assets\pathmark.ico" DevelopmentSystemLauncher.py
  goto done
)

echo Python was not found. Please install Python 3.11 or later and try again.
pause
exit /b 1

:done
if exist "dist\Pathmark.exe" (
  copy /Y "dist\Pathmark.exe" "Pathmark.exe" >nul
  echo.
  echo Built Pathmark.exe in this folder. You can pin this file to the taskbar after opening it.
) else (
  echo Build finished but the expected exe was not found.
)
pause
