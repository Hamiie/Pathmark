# v0.5.16 changes

- Streamlit top bar is dark-mode friendly and less visually prominent.
- Tasklist PDFs now export to `output/Tasklists`.
- Google Calendar ICS files now export to `output/Google Calendar Exports`.
- Google Tasks CSV files now export to `output/Google Tasks Exports`.
- Backups now export to `output/Backups`.
- Latest export controls are shown even after staged rows move to Exported, so Open file/Open folder does not disappear after exporting.
- Settings includes explicit export folder paths.
- Settings includes an update backup workflow and optional update hub URL.
- Launcher source includes a Check for updates button that creates a database backup before opening the update hub. Rebuild the EXE on Windows to include launcher UI changes.
