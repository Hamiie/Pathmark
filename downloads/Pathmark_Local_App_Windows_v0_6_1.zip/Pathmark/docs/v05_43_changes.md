# v0.5.43 changes

- Pathmark.exe prompts for the workspace folder on first launch before the app starts.
- The launcher can create Documents\Pathmark or point Pathmark to an existing workspace folder.
- The workspace is explained as the location for projects, area folders, exports, tasklists, backups, and the local database.
- The launcher setup includes default theme selection.
- Theme and launcher settings are saved locally and included in launcher backups.
- The Streamlit app respects the launcher-selected workspace so exports do not create a separate Documents\Pathmark folder unexpectedly.
- The in-app Settings page no longer includes a Downloads shortcut.
