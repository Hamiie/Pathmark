# v0.5.84 changes

- Continued Pathmark Online development in the hosted release hub.
- Added action-block/routine-activity mechanics to the online version.
- Reduced Google Sheets read quota pressure with batch reads and session caching.
- Local desktop app package was republished so update metadata matches the hosted release.
