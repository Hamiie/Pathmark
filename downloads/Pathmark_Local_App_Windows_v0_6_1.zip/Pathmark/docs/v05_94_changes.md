# v0.5.94 changes

This local package accompanies the hosted Pathmark Online v0.5.94 release. Local desktop functionality is unchanged in this release.
