# v0.5.78 changes

- Updated hosted On-the-go Google Sheets OAuth to avoid PKCE code-verifier loss during Streamlit/Google redirect round trips.
- Preserved signed OAuth state and server-side-only Google client secret handling.
- No local Workspace data model changes.
