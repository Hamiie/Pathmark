# v0.5.89 changes

- Polished Pathmark Online user-facing guidance.
- Removed backend/developer-facing parity language from normal online screens.
- Improved the online printable PDF tasklist and removed the plain text tasklist option from the normal interface.
- Replaced code-style diagnostic output with safer, user-facing summaries.
