# Pathmark Google Tasks import setup

Pathmark exports Google Tasks prompts as a CSV file. Google Tasks does not provide a normal CSV import button, so the import is done through a small Google Apps Script attached to a Google Sheet.

This setup is only needed once per Google account.

## First-time setup

1. Open Google Drive.
2. Create a new Google Sheet called `Pathmark Task Import`.
3. In the Google Sheet, go to **Extensions > Apps Script**.
4. Delete any starter code.
5. Copy the contents of `docs/import_pathmark_tasks_to_google_tasks.gs` into Apps Script.
6. Enable the advanced Google Tasks service:
   - Click **Services** on the left.
   - Click **Add a service**.
   - Choose **Tasks API**.
   - Click **Add**.
7. Save the project.
8. Run `importPathmarkTasksToGoogleTasks` once.
9. Google will ask you to authorise the script. Approve it for your own account.

## Each import

1. Export Google Tasks from Pathmark.
2. Open the CSV file from `00_System/Google Tasks Exports`.
3. Copy the rows into your `Pathmark Task Import` Google Sheet.
4. Keep the header row exactly as exported.
5. In Apps Script, run `importPathmarkTasksToGoogleTasks`.

## Required CSV columns

Pathmark exports these columns first:

- Task ID
- Task List
- Title
- Notes
- Due Date
- Reminder Time
- Status

Extra columns can appear after these. The script ignores them.

## Notes

- Google Tasks due dates store the date only. Pathmark keeps the reference time in the task notes.
- Repeating routine prompts are exported as individual CSV rows, not as true repeating Google Tasks.
- Google Calendar remains the main place for recurring time blocks.
- Google Tasks prompts are intended to reduce friction to begin the work.
