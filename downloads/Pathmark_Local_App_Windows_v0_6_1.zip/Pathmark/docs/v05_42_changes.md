# v0.5.42 changes

- Made launcher update/backup actions visible in the main launcher window.
- Renamed update action to **Backup and open update hub**.
- Added workspace README creation for the selected Pathmark folder.
- Set the new-install default appearance to the product-page-style Pathmark theme.
- Excluded `00_System` from Area import more reliably.
- Fixed auto-imported Area colours to use valid Google Calendar colour names instead of falling back to Graphite.
- Clarified export success messages so they refer to the visible **Open ... Exports folder** button.
