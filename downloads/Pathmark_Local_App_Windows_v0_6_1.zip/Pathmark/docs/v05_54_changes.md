# v0.5.54 changes

- Fixed the Streamlit Cloud deployment dependency error by adding PyYAML to the release hub requirements.
- Aligned the public release hub requirements with the local Windows app requirements: Streamlit, pandas, PyYAML, reportlab, and Pillow.
- No workflow change: this release is a dependency fix for the hosted download page and local install requirements.
