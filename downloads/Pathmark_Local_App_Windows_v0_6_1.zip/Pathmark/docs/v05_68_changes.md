# v0.5.68 changes

- Updated the hosted release hub dependency to `streamlit[auth]` so Streamlit login installs the required authentication package.
- Removed the misleading empty bar above the hosted login panel.
- Changed logged-out access wording from `public` to `download only`.
- Kept beta/developer features behind verified Google login and role checks.
