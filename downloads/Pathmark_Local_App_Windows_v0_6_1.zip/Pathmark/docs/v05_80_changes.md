# v0.5.80

- Polished the hosted signed-in header so the user email and access level are shown once, with a clear Log out control.
- Simplified the hosted Web companion beta page by hiding diagnostics and advanced Google Sheet controls by default.
- Clarified the long-term architecture: online Pathmark as a Google-Sheet-backed routine and goal manager, and desktop Pathmark as the local Workspace, Markdown, backup, review/import, and export publisher.

No local Workspace data model changes were made in this package.
