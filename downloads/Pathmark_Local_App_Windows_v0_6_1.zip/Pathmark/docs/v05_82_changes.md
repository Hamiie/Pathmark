# v0.5.82 changes

- Hosted release hub rewrite: clearer product framing for Pathmark Online and Pathmark Desktop.
- Added public privacy and storage guidance explaining the local Workspace, user-owned Google Sheet, Supabase access layer, and GitHub release boundary.
- Desktop app files are otherwise unchanged in this release.
