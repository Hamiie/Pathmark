# v0.4 changes

This build is a model/interface rethink rather than a light patch of v0.3.

## Visual system

- Separate light and dark palettes.
- Muted autumn palette with restrained buttons.
- Card spacing and line-height improved.
- No decorative warning symbols.
- Dropdown/input colours are defined separately for each mode.

## Goals and projects

- Simplified statuses: Captured, Active, On hold, Closed, Abandoned.
- Removed Clarifying, Waiting, Paused, Ready to close, and Archived as goal statuses.
- Archive is a destination/view, not a status.
- Removed phase and current focus fields.
- Actions now sit under the selected goal.
- Goal details, actions, and closure criteria are editable from the same selected-goal view.
- Archiving a goal includes a closure review.

## Routines

- Routines are not treated as mini-projects.
- Routine fields: name, core area, purpose, frequency, next due, status, notes.
- Includes core-area examples.
- Routines can be completed, retired, edited, or archived.

## Areas and folder system

- Areas include folder path and Markdown path.
- Default sandbox root is `Documents/Development_Sandbox`.
- The app can create missing area folders and Markdown files.

## Review Queue

- More readable card format.
- Human-facing labels.
- Table is secondary.
- No underscores or internal IDs in the main user-facing view.

## Exports

- Pages are called Google Calendar Export and Google Tasks Export.
- Filters include all areas, not only Work.
- Export selected rows, export current area, or remove selected rows from export.

## Weekly checklist

- PDF export retained.
- Google Calendar time is not shown as a separate section.
- Checklist sections are: main focus, planned actions, routines to maintain wellbeing, fixed commitments, and end-of-week review.
