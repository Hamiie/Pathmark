# v0.5.83 changes

- Hosted Pathmark Online beta has moved closer to the desktop planning model.
- Added online Google-Sheet-backed management screens for Areas, Goals and Projects, Routines, Calendar Blocks, Task Prompts, Tasklists, and Exports.
- Added browser downloads for calendar ICS files, Google Tasks CSV, and printable tasklists from the online sync sheet.
- The desktop app remains responsible for the local Workspace, Markdown generation, backups, and heavier publishing.
- No personal planning data is stored in Supabase.
