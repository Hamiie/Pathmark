# v0.5.15 changes

- Google Tasks export is comma-delimited CSV again.
- Google Tasks exports write to the configured GoogleTasksExports folder.
- Repeating routines now export one next Google Tasks prompt row by default.
- The Google Tasks Export page includes a Routine prompt rows selector for deliberately preparing 1, 2, 4, or 8 future prompt rows.
- Google Calendar continues to export repeating routine activities as recurring ICS events using RRULE.

Rationale: the Google Tasks CSV/App Script workflow creates one task per row. It does not create a single recurring task from a repeat pattern, so exporting many future occurrences by default clutters Google Tasks.
