# v0.5.81 changes

- Hosted release hub update: unified Google login and Google Sheets/Drive access for Pathmark Online.
- Google login now requests the narrow `drive.file` scope so the Web Companion can prepare a user-owned Pathmark sync sheet without a separate Google Sheets connection step.
- The desktop app package is included so release metadata and update checks align with the hosted hub; local Workspace behaviour is otherwise unchanged.
