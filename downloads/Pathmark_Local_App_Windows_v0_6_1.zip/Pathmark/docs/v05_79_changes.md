# v0.5.79

- Hosted release hub: fixed Google Sheets On-the-go connected-state persistence after OAuth.
- Hosted release hub: attempts to create a Pathmark sync sheet automatically after connection.
- Local app package included to keep release metadata aligned.
