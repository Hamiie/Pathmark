# v0.5.88 changes

- Restored the hosted Google OAuth launch control to Streamlit native link buttons for reliability.
- Preserved the Pathmark Online refinements from v0.5.87.
