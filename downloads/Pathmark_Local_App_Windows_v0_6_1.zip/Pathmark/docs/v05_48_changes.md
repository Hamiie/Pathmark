# v0.5.48 changes

- Simplified the public download page so it does not repeat the same introductory information in several places.
- Restyled launcher controls with softer rounded buttons.
- Hid the visual launcher scrollbar while keeping mouse-wheel scrolling.
- Strengthened Default theme button text contrast in the local app.
- Kept Area detection restricted to numbered folders and continued to reserve 00_System.
