# v0.5.57 changes

- Corrected public documentation so the replaceable app folder is `Documents\Pathmark` and the default user Workspace remains `Documents\Workspace`.
- Kept `Documents\Workspace` as the default user Workspace.
- Confirmed the hosted release hub is a download homepage only and should not render local app setup/debug snippets.
- Improved Google Calendar colour assignment for imported numbered Area folders so active Areas use different colours where possible.
- Removed prompt-like wording from the Area folder detection docstring to avoid confusing surfaced error/debug output.
