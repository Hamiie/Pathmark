# v0.5.44 changes

- Polished the Windows launcher to better match the public Pathmark homepage.
- Default workspace is now `Documents\Workspace`, with a launcher field and Browse option to change it before launch.
- Removed the separate launcher backup-only action; the launcher now has a single Update action that creates an update backup and opens the update hub.
- Renamed the default visual theme to `Default` and made it more closely match the Pathmark homepage/launcher style.
- Launcher and in-app theme settings now sync so an old Iris setting does not override the launcher choice.
- Simplified visible backup/update options inside the app; updates are handled from the launcher.
