# v0.5.73 changes

This release updates the hosted Pathmark release hub Supabase access layer to prefer Supabase Secret API keys (`sb_secret_...`) rather than legacy JWT-based `service_role` keys.

The local desktop app is otherwise unchanged from v0.5.72.

## Hosted release hub

- Uses `[supabase].secret_key` for new Supabase setups.
- Still accepts `[supabase].service_role_key` as a fallback for older deployments.
- Sends Secret API keys using the `apikey` header only.
- Keeps legacy service-role keys using the existing `Authorization: Bearer ...` behaviour.
- Updates setup guidance to enable Row Level Security on the hosted access-control tables.
