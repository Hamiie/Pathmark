# v0.5.92 changes

- Companion package for hosted Pathmark Online privacy, guidance and stability refinements.
- No desktop mechanics changed in this release.
