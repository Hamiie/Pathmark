# v0.5.64 changes

- Hardened user-authorised OAuth for the On the go Google Sheets sync prototype.
- Changed Google sync to request the narrower `drive.file` scope.
- Hosted OAuth now uses strict state validation.
- Hosted OAuth uses session-only access and does not retain refresh tokens.
- Added a local Disconnect Google action for removing the Workspace OAuth token.
- CSV import/export remains available as the fallback workflow.
