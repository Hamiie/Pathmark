# v0.5.93 changes

- Hosted Pathmark Online mobile contrast refinement.
- Local desktop functionality is unchanged.
