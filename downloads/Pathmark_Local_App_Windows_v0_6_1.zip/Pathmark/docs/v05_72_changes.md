# v0.5.72 changes

- Added a Supabase-backed access layer to the hosted Pathmark release hub for longer-term user roles, feature flags, and audit logs.
- Removed the Google Sheet service-account role-store model from the hosted Developer panel.
- Kept Google login for identity and kept user-owned Google Sheets for on-the-go planning sync.
- Clarified that Supabase is for hosted access control only and should not store Pathmark goals, routines, task prompts, Workspace files, or on-the-go entries.
