# v0.5.67 changes

- Hosted release hub login controls are now more visible.
- If Streamlit `[auth]` is not configured, the hosted page clearly shows download-only mode rather than hiding the login workflow.
- Added Authlib dependency for Streamlit OIDC login support.
