# v0.5.91 changes

- Companion package for hosted Pathmark Online guidance and homepage refinements.
- No desktop application mechanics changed.
