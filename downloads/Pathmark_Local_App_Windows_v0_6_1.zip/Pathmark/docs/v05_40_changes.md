# v0.5.40 changes

- Windows-only release hub while the Windows installation, update, and folder workflows are stabilised.
- Removed the Mac download panel from the release hub.
- Added a safer Windows package lookup in the release hub, so it can find the package in `downloads/` even if the exact filename in `latest_version.json` is not present.
- Kept the local launcher backup and backup-and-update options.
- Kept the Documents\Pathmark default and area-folder detection changes from v0.5.39.
