@echo off
setlocal
cd /d "%~dp0"
py -3 tools\GoogleTasksSetupHelper.py
if errorlevel 1 (
  python tools\GoogleTasksSetupHelper.py
)
