Pathmark Local App Windows v0.6.92

This package accompanies the v0.6.92 release hub.
