# v0.6.91 changes

- Revised default Pathmark Areas.
- Focus-based projects cannot be switched back to task-based while focus blocks exist.
- Supporting time blocks and helper checklist items do not count toward project progress.
