# v0.6.56 Finance Template sheet and contrast refinement

- Spending Plan Template now creates or refreshes a separate Google Sheet named **Pathmark Finance Template**.
- The template is populated from the current user's existing Spending Plan income and outflow rows.
- Import reads from the separate Finance Template and writes back to Pathmark Sync after creating backup tabs.
- Removed the duplicate Pathmark Sync open button from the Template tab.
- Summary strips now show available-to-allocate or shortfall rather than presenting safe weekly spend as the Available signal.
- Pathmark-owned surfaces, borders, headings and muted text now resolve against Streamlit's actual background/text variables for better light/dark contrast.
