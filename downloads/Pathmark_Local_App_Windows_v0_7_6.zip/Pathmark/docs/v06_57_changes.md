# v0.6.57 Google Tasks sync foundation

- Adds direct Google Tasks sync in Pathmark Online.
- Creates/reuses a Google Tasks list called Pathmark.
- Pushes Pathmark checklist items to Google Tasks and stores returned Google task IDs.
- Pulls completion status back into Pathmark.
- Keeps CSV and sync-sheet export as a fallback.
