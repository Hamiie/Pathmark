# v0.6.54 — Spending Plan money-flow dashboard and tab navigation

- Dashboard Resources now shows money available to allocate, balanced flow, or shortfall.
- Positive unallocated money is framed as money to move toward emergency, savings, debt, or planned irregular costs.
- Overcommitted Spending Plans show a shortfall state rather than a positive safe-spend signal.
- Spending Plan sections now use tab-style navigation consistent with Pathmark Online beta.
