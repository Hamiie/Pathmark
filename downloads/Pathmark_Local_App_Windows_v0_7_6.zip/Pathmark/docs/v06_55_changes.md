# v0.6.55 changes

- Changes Spending Plan Assessment so the Available card shows money available to allocate, balanced flow, or shortfall rather than safe weekly spend.
- Adds Spending Plan template tools that create populated user-friendly Google Sheet tabs for income and outflows, then import them back with merge or clean import options.
- Creates Spending Plan backup tabs before importing template data.
- Updates starter spending notes to say edit, set to 0, or delete instead of archive.
- Refines theme persistence so Supabase profile saving is optional when the theme can be saved to the user-owned Pathmark Sync sheet.
- Tightens contrast tokens so Pathmark-owned muted text uses paired surface/text contrast rules in dark mode.
