# Pathmark Local App v0.7.23 — Inventory organisation and stock movement foundation

Architecture and performance foundation release.
