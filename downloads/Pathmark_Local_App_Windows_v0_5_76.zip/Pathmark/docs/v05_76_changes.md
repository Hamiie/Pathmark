# v0.5.76 changes

- Hosted release hub: fixed Google Sheets OAuth return handling for the On-the-go beta.
- Hosted release hub: changed Google login and Google Sheets connection controls to same-tab links.
- No local Workspace schema changes.
